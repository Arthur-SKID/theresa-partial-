
package cn.theresa.features.other.command.commands

import cn.theresa.ClientMain
import cn.theresa.features.other.command.Command
import cn.theresa.features.other.command.CommandManager
import cn.theresa.ui.client.clickgui.ClickGui
import cn.theresa.ui.client.clickgui.newVer.NewUi
import cn.theresa.ui.font.Fonts
import cn.theresa.utils.misc.sound.TipSoundManager

class ReloadCommand : Command("reload", arrayOf("configreload")) {
    /**
     * Execute commands with provided [args]
     */
    override fun execute(args: Array<String>) {
        chat("Reloading...")
        chat("§c§lReloading commands...")
        ClientMain.commandManager = CommandManager()
        ClientMain.commandManager.registerCommands()
        ClientMain.isStarting = true
        ClientMain.scriptManager.disableScripts()
        ClientMain.scriptManager.unloadScripts()
        for(module in ClientMain.moduleManager.modules)
            ClientMain.moduleManager.generateCommand(module)
        chat("§c§lReloading scripts...")
        ClientMain.scriptManager.loadScripts()
        ClientMain.scriptManager.enableScripts()
        chat("§c§lReloading fonts...")
        Fonts.loadFonts()
        chat("§c§lReloading toggle audio files...")
        ClientMain.tipSoundManager = TipSoundManager()
        chat("§c§lReloading modules...")
        ClientMain.fileManager.loadConfig(ClientMain.fileManager.modulesConfig)
        ClientMain.isStarting = false
        chat("§c§lReloading values...")
        ClientMain.fileManager.loadConfig(ClientMain.fileManager.valuesConfig)
        chat("§c§lReloading accounts...")
        ClientMain.fileManager.loadConfig(ClientMain.fileManager.accountsConfig)
        chat("§c§lReloading friends...")
        ClientMain.fileManager.loadConfig(ClientMain.fileManager.friendsConfig)
        chat("§c§lReloading xray...")
        ClientMain.fileManager.loadConfig(ClientMain.fileManager.xrayConfig)
        chat("§c§lReloading HUD...")
        ClientMain.fileManager.loadConfig(ClientMain.fileManager.hudConfig)
        chat("§c§lReloading ClickGUI...")
        ClientMain.clickGui = ClickGui()
        ClientMain.fileManager.loadConfig(ClientMain.fileManager.clickGuiConfig)
        chat("§c§lReloading NewGUI...")
        NewUi.resetInstance()
        ClientMain.isStarting = false
        chat("Reloaded.")
    }
}
