/*
 * Theresa Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge(OLD).
 * https://github.com/WYSI-Foundation/LiquidBouncePlus/
 * LZTN
 * This code belongs to WYSI-Foundation. Please give credits when using this in your repository.
 */
package cn.theresa.features.other.command.commands

import cn.theresa.features.other.command.Command
import cn.theresa.features.module.modules.misc.AntiBot

class TeleportCommand : Command("tp", emptyArray()) {

    /**
     * Execute commands with provided [args]
     */
    override fun execute(args: Array<String>) {
        if (args.size == 2) {
            val theName = args[1]

            // Get target player data
            val targetPlayer = mc.theWorld.playerEntities
                    .filter { !AntiBot.isBot(it) && it.name.equals(theName, true) }
                    .firstOrNull()

            // Attempt to teleport to player's position.
            if (targetPlayer != null) {
                mc.thePlayer.setPositionAndUpdate(targetPlayer!!.posX, targetPlayer!!.posY, targetPlayer!!.posZ)
                chat("Attempted to teleport you to §a${targetPlayer!!.name}§3.")
                return
            } else {
                chat("§6We couldn't find any player in the current world with that name.")
                return
            }
        }
        else if (args.size == 4) {
            try {
                val posX = if (args[1].equals("~", true)) mc.thePlayer.posX else args[1].toDouble()
                val posY = if (args[2].equals("~", true)) mc.thePlayer.posY else args[2].toDouble()
                val posZ = if (args[3].equals("~", true)) mc.thePlayer.posZ else args[3].toDouble()

                mc.thePlayer.setPositionAndUpdate(posX, posY, posZ)
                chat("Attempted to teleport you to §a$posX, $posY, $posZ§3.")
                return
            } catch (e: NumberFormatException) {
                chat("§6Please check if you have typed the numbers correctly, and try again.")
                return
            }
        }

        chatSyntax("teleport/tp <player name/x y z>")
    }

    override fun tabComplete(args: Array<String>): List<String> {
        if (args.isEmpty()) return emptyList()

        val pref = args[0]

        return when (args.size) {
            1 -> mc.theWorld.playerEntities
                    .filter { !AntiBot.isBot(it) && it.name.startsWith(pref, true) }
                    .map { it.name }
                    .toList()
            else -> emptyList()
        }
    }

}