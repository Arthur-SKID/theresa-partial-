
package cn.theresa.features.module.modules.movement

import cn.theresa.event.EventTarget
import cn.theresa.event.JumpEvent
import cn.theresa.event.UpdateEvent
import cn.theresa.features.module.manager.Module
import cn.theresa.features.module.manager.ModuleCategory
import cn.theresa.features.module.manager.ModuleInfo
import cn.theresa.utils.MovementUtils
import cn.theresa.value.FloatValue
import cn.theresa.value.ListValue

@ModuleInfo(name = "NoWeb", spacedName = "No Web", description = "Prevents you from getting slowed down in webs.", category = ModuleCategory.MOVEMENT, cnName = "无减速")
class NoWeb : Module() {

    private val modeValue = ListValue("Mode", arrayOf("None", "AAC", "LAAC", "Rewi", "AACv4", "Cardinal", "Horizon", "Spartan", "Negativity"), "None")
    private val horizonSpeed = FloatValue("HorizonSpeed", 0.1F, 0.01F, 0.8F)

    private var usedTimer = false
    @EventTarget
    fun onUpdate(event: UpdateEvent) {
        if (usedTimer) {
            mc.timer.timerSpeed = 1F
            usedTimer = false
        }
        if (!mc.thePlayer.isInWeb)
            return

        when (modeValue.get().toLowerCase()) {
            "none" -> mc.thePlayer.isInWeb = false
            "aac" -> {
                mc.thePlayer.jumpMovementFactor = 0.59f

                if (!mc.gameSettings.keyBindSneak.isKeyDown)
                    mc.thePlayer.motionY = 0.0
            }
            "laac" -> {
                mc.thePlayer.jumpMovementFactor = if (mc.thePlayer.movementInput.moveStrafe != 0f) 1.0f else 1.21f

                if (!mc.gameSettings.keyBindSneak.isKeyDown)
                    mc.thePlayer.motionY = 0.0

                if (mc.thePlayer.onGround)
                    mc.thePlayer.jump()
            }
            "rewi" -> {
                mc.thePlayer.jumpMovementFactor = 0.42f

                if (mc.thePlayer.onGround)
                    mc.thePlayer.jump()
            }
            //i hate this
            "aacv4" -> {
                mc.gameSettings.keyBindRight.pressed = false
                mc.gameSettings.keyBindBack.pressed = false
                mc.gameSettings.keyBindLeft.pressed = false

                if(mc.thePlayer.onGround){
                    MovementUtils.strafe(0.25F)
                }else{
                    MovementUtils.strafe(0.12F)
                    mc.thePlayer.motionY = 0.0
                }
            }
            "cardinal" -> {
                if(mc.thePlayer.onGround){
                    MovementUtils.strafe(0.262F)
                }else{
                    MovementUtils.strafe(0.366F)
                }
            }
            "horizon" -> {
                if(mc.thePlayer.onGround){
                    MovementUtils.strafe(horizonSpeed.get())
                }
            }
            "spartan" -> {
                MovementUtils.strafe(0.27F)
                mc.timer.timerSpeed = 3.7F
                if (!mc.gameSettings.keyBindSneak.isKeyDown)
                    mc.thePlayer.motionY = 0.0
                if(mc.thePlayer.ticksExisted % 2 == 0){
                    mc.timer.timerSpeed = 1.7F
                }
                if(mc.thePlayer.ticksExisted % 40 == 0){
                    mc.timer.timerSpeed = 3F
                }
                usedTimer = true
            }
            "negativity" -> {
                mc.thePlayer.jumpMovementFactor = 0.4f
                if(mc.thePlayer.ticksExisted % 2 == 0){
                    mc.thePlayer.jumpMovementFactor = 0.53F
                }
                if (!mc.gameSettings.keyBindSneak.isKeyDown)
                    mc.thePlayer.motionY = 0.0
            }
        }
    }
    fun onJump(event : JumpEvent){
        if(modeValue.get().equals("AACv4", true) || modeValue.get().equals("Negativity", true) || modeValue.get().equals("Intave", true))
            event.cancelEvent()
    }

    override fun onDisable() {
        mc.timer.timerSpeed = 1.0F
    }


    override val tag: String?
        get() = modeValue.get()
}
