
package cn.theresa.features.module.modules.world

import cn.theresa.event.EventTarget
import cn.theresa.event.UpdateEvent
import cn.theresa.features.module.manager.Module
import cn.theresa.features.module.manager.ModuleCategory
import cn.theresa.features.module.manager.ModuleInfo
import cn.theresa.value.FloatValue

@ModuleInfo(name = "FastBreak", spacedName = "Fast Break", description = "Allows you to break blocks faster.", category = ModuleCategory.WORLD, cnName = "快速放置")
class FastBreak : Module() {

    private val breakDamage = FloatValue("BreakDamage", 0.8F, 0.1F, 1F)

    @EventTarget
    fun onUpdate(event: UpdateEvent) {
        mc.playerController.blockHitDelay = 0

        if (mc.playerController.curBlockDamageMP > breakDamage.get())
            mc.playerController.curBlockDamageMP = 1F

        if (Fucker.currentDamage > breakDamage.get())
            Fucker.currentDamage = 1F
    }
}
