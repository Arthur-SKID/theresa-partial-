
package cn.theresa.features.module.modules.render

import cn.theresa.features.module.manager.Module
import cn.theresa.features.module.manager.ModuleCategory
import cn.theresa.features.module.manager.ModuleInfo

@ModuleInfo(name = "NoHurtCam", spacedName = "No Hurt Cam", description = "Disables hurt cam effect when getting hurt.", category = ModuleCategory.RENDER, cnName = "无受击界面")
class NoHurtCam : Module()
