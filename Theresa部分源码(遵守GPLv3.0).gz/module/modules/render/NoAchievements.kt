
package cn.theresa.features.module.modules.render

import cn.theresa.features.module.manager.Module
import cn.theresa.features.module.manager.ModuleCategory
import cn.theresa.features.module.manager.ModuleInfo

@ModuleInfo(name = "NoAchievements", spacedName = "No Achievements", description = "Remove achievement notifications from your screen.", category = ModuleCategory.RENDER, cnName = "取消消息")
class NoAchievements : Module()