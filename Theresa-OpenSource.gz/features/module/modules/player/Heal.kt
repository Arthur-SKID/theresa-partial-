/*
 * Theresa Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge(OLD).
 * https://github.com/WYSI-Foundation/LiquidBouncePlus/
 * LZTN
 * This code belongs to WYSI-Foundation. Please give credits when using this in your repository.
 */
package cn.theresa.features.module.modules.player

import cn.theresa.event.EventTarget
import cn.theresa.features.module.manager.ModuleCategory
import cn.theresa.value.FloatValue
import cn.theresa.value.IntegerValue
import cn.theresa.value.BoolValue
import cn.theresa.utils.timer.MSTimer
import net.minecraft.util.MathHelper
import cn.theresa.event.PacketEvent
import net.minecraft.network.play.server.S02PacketChat
import cn.theresa.utils.ClientUtils
import cn.theresa.event.UpdateEvent
import cn.theresa.features.module.manager.Module
import cn.theresa.features.module.manager.ModuleInfo
import cn.theresa.utils.MovementUtils
import net.minecraft.client.gui.inventory.GuiContainer
import net.minecraft.item.ItemStack
import net.minecraft.network.play.client.C09PacketHeldItemChange
import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement
import net.minecraft.network.play.client.C03PacketPlayer
import net.minecraft.init.Items
import net.minecraft.potion.Potion
import org.apache.commons.lang3.tuple.Pair
import java.util.*

@ModuleInfo(
    name = "Heal",
    description = "Automatically eats Gapple. (only for some servers with a broken anticheat)",
    category = ModuleCategory.PLAYER,
    cnName = "自动吃苹果"
)
class Heal : Module() {
    private val percent = FloatValue("HealthPercent", 75.0f, 1.0f, 100.0f, "%")
    private val min = IntegerValue("MinDelay", 75, 1, 5000, "ms")
    private val max = IntegerValue("MaxDelay", 125, 1, 5000, "ms")
    private val regenSec = FloatValue("RegenSec", 4.6f, 0.0f, 10.0f)
    private val groundCheck = BoolValue("GroundCheck", false)
    private val voidCheck = BoolValue("VoidCheck", true)
    private val waitRegen = BoolValue("WaitRegen", true)
    private val invCheck = BoolValue("InvCheck", false)
    private val absorpCheck = BoolValue("AbsorpCheck", true)
    val timer = MSTimer()
    var delay = 0
    var isDisable = false
    override fun onEnable() {
        super.onEnable()
        timer.reset()
        isDisable = false
        delay = MathHelper.getRandomIntegerInRange(Random(), min.get(), max.get())
    }

    @EventTarget
    fun onPacket(e: PacketEvent) {
        if (e.packet is S02PacketChat && e.packet.chatComponent.formattedText.contains("§r§7 won the game! §r§e\u272a§r")) {
            ClientUtils.displayChatMessage("§f[§cSLHeal§f] §6Temp Disable Heal")
            isDisable = true
        }
    }

    @EventTarget
    fun onUpdate(event: UpdateEvent?) {
        if (mc.thePlayer.ticksExisted <= 5 && isDisable) {
            isDisable = false
            ClientUtils.displayChatMessage("§f[§cSLHeal§f] §6Enable Heal due to World Changed or Player Respawned")
        }
        val absorp = MathHelper.ceiling_double_int(mc.thePlayer.absorptionAmount.toDouble())
        if (groundCheck.get() && !mc.thePlayer.onGround || voidCheck.get() && !MovementUtils.isBlockUnder() || invCheck.get() && mc.currentScreen is GuiContainer || absorp != 0 && absorpCheck.get())
            return
        if (waitRegen.get() && mc.thePlayer.isPotionActive(Potion.regeneration) && mc.thePlayer.getActivePotionEffect(Potion.regeneration).duration > regenSec.get() * 20.0f)
            return
        val pair = gAppleSlot
        if (!isDisable && pair != null && (mc.thePlayer.health <= percent.get() / 100.0f * mc.thePlayer.maxHealth || !mc.thePlayer.isPotionActive(Potion.absorption) || absorp == 0 && mc.thePlayer.health == 20.0f && mc.thePlayer.isPotionActive(Potion.absorption)) && timer.hasTimePassed(delay.toLong())) {
            ClientUtils.displayChatMessage("§f[§cSLHeal§f] §6Healed")
            val lastSlot = mc.thePlayer.inventory.currentItem
            val slot = pair.left as Int
            mc.netHandler.addToSendQueue(C09PacketHeldItemChange(slot))
            val stack = pair.right as ItemStack
            mc.netHandler.addToSendQueue(C08PacketPlayerBlockPlacement(stack))
            for (i in 0..31) {
                mc.netHandler.addToSendQueue(C03PacketPlayer())
            }
            mc.netHandler.addToSendQueue(C09PacketHeldItemChange(lastSlot))
            mc.thePlayer.inventory.currentItem = lastSlot
            mc.playerController.updateController()
            delay = MathHelper.getRandomIntegerInRange(Random(), min.get(), max.get())
            timer.reset()
        }
    }

    private val gAppleSlot: Pair<Int, ItemStack>?
        private get() {
            for (i in 0..8) {
                val stack = mc.thePlayer.inventory.getStackInSlot(i)
                if (stack != null && stack.item === Items.golden_apple) {
                    return Pair.of(i, stack)
                }
            }
            return null
        }
    override val tag: String?
        get() = if (mc.thePlayer == null || mc.thePlayer.health == Float.NaN) null else String.format(
            "%.2f HP",
            percent.get() / 100.0f * mc.thePlayer.maxHealth
        )
}