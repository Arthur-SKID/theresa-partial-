
package cn.theresa.features.module.modules.misc

import cn.theresa.ClientMain
import cn.theresa.event.EventTarget
import cn.theresa.event.Render2DEvent
import cn.theresa.features.module.manager.Module
import cn.theresa.features.module.manager.ModuleCategory
import cn.theresa.features.module.manager.ModuleInfo
import cn.theresa.utils.ClientUtils
import cn.theresa.utils.render.ColorUtils
import net.minecraft.entity.player.EntityPlayer
import org.lwjgl.input.Mouse

@ModuleInfo(name = "MidClick", spacedName = "Mid Click", description = "Allows you to add a player as a friend by middle clicking them.", category = ModuleCategory.MISC, cnName = "中建选择朋友")
class MidClick : Module() {
    private var wasDown = false

    @EventTarget
    fun onRender2D(event: Render2DEvent) {
        if (mc.currentScreen != null) return

        if (wasDown && Mouse.isButtonDown(2)) {
            val entity = mc.objectMouseOver.entityHit
            if (entity != null && entity is EntityPlayer) {
                val playerName = ColorUtils.stripColor(entity!!.name)
                val friendsConfig = ClientMain.fileManager.friendsConfig

                if (friendsConfig.isFriend(playerName)) {
                    friendsConfig.removeFriend(playerName)
                    ClientMain.fileManager.saveConfig(friendsConfig)
                    ClientUtils.displayChatMessage("§a§l$playerName§c was removed from your friends.")
                } else {
                    friendsConfig.addFriend(playerName)
                    ClientMain.fileManager.saveConfig(friendsConfig)
                    ClientUtils.displayChatMessage("§a§l$playerName§c was added to your friends.")
                }
            } else
                ClientUtils.displayChatMessage("§c§lError: §aYou need to select a player.")
        }
    }
}