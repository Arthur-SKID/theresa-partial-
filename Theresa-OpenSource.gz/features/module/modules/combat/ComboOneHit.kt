
package cn.theresa.features.module.modules.combat

import cn.theresa.ClientMain
import cn.theresa.event.*
import cn.theresa.features.module.manager.Module
import cn.theresa.features.module.manager.ModuleCategory
import cn.theresa.features.module.manager.ModuleInfo
import cn.theresa.value.IntegerValue
import cn.theresa.value.BoolValue
import net.minecraft.network.play.client.C02PacketUseEntity
import net.minecraft.network.play.client.C0APacketAnimation

@ModuleInfo(name = "ComboOneHit", spacedName = "Combo One Hit", description = "Automatically deals hits within one click. Only works if no attack delay is present.", category = ModuleCategory.COMBAT, cnName = "自动处理命中")
class ComboOneHit : Module() {

    private val amountValue = IntegerValue("Packets", 200, 0, 500, "x")
    private val swingItemValue = BoolValue("SwingPacket", false)
    private val onlyAuraValue = BoolValue("OnlyAura", false)

    @EventTarget
    fun onAttack(event: AttackEvent) {
        event.targetEntity ?: return
        if (onlyAuraValue.get() && !ClientMain.moduleManager[KillAura::class.java]!!.state && !ClientMain.moduleManager[TeleportAura::class.java]!!.state) return

        repeat (amountValue.get()) {
            mc.netHandler.addToSendQueue(C0APacketAnimation())
            mc.netHandler.addToSendQueue(C02PacketUseEntity(event.targetEntity, C02PacketUseEntity.Action.ATTACK))
        }
    }

}
