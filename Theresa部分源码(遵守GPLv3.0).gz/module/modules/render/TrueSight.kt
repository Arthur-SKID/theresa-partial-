
package cn.theresa.features.module.modules.render

import cn.theresa.features.module.manager.Module
import cn.theresa.features.module.manager.ModuleCategory
import cn.theresa.features.module.manager.ModuleInfo
import cn.theresa.value.BoolValue

@ModuleInfo(name = "TrueSight", spacedName = "True Sight", description = "Allows you to see invisible entities and barriers.", category = ModuleCategory.RENDER, cnName = "看到屏障")
class TrueSight : Module() {
    val barriersValue = BoolValue("Barriers", true)
    val entitiesValue = BoolValue("Entities", true)
}