
package cn.theresa.features.other.command.commands

import cn.theresa.ClientMain
import cn.theresa.features.other.command.Command

class PrefixCommand : Command("prefix", emptyArray()) {
    /**
     * Execute commands with provided [args]
     */
    override fun execute(args: Array<String>) {
        if (args.size <= 1) {
            chatSyntax("prefix <character>")
            return
        }

        val prefix = args[1]

        if (prefix.length > 1) {
            chat("§cPrefix can only be one character long!")
            return
        }

        ClientMain.commandManager.prefix = prefix.single()
        ClientMain.fileManager.saveConfig(ClientMain.fileManager.valuesConfig)

        chat("Successfully changed command prefix to '§8$prefix§3'")
    }
}