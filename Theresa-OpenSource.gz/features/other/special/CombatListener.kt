package cn.theresa.features.other.special

import cn.theresa.ClientMain
import cn.theresa.event.*
import net.minecraft.entity.EntityLivingBase
import net.minecraft.network.handshake.client.C00Handshake
import net.minecraft.network.play.server.S45PacketTitle
import java.util.*

object CombatListener : Listenable {
        var syncEntity: EntityLivingBase? = null
        var killCounts = 0
        var totalPlayed = 0
        var win = 0
        var startTime = System.currentTimeMillis()

@EventTarget
private fun onAttack(event: AttackEvent) { syncEntity = event.targetEntity as EntityLivingBase?
        }

@EventTarget
private fun onUpdate(event: UpdateEvent) {
        if(syncEntity != null && syncEntity!!.isDead) {
        ++killCounts
        syncEntity = null
        }
        }

@EventTarget(ignoreCondition = true)
private fun onPacket(event: PacketEvent) {
        val packet = event.packet
        if (event.packet is C00Handshake) startTime = System.currentTimeMillis()

        if (packet is S45PacketTitle) {
        val title = packet.message.formattedText
        if(title.contains("Winner")){
        win++
        }
        if(title.contains("BedWar")){
        totalPlayed++
        }
        if(title.contains("SkyWar")){
        totalPlayed++
        }
        }
        }

        override fun handleEvents() = true

        init {
        ClientMain.eventManager.registerListener(this)
        }

        fun getRandomFloatNum(range : Int, decimal: Int) : Float {
                val floatRandomNum =  Random().nextInt(range) + Random().nextFloat()
                // 0则不带小数点，6则带6位小数点，不在这个范围都是2个小数点
                val mDecimal = if(decimal in 0..6) decimal else 2
                return String.format("%." + mDecimal + "f", floatRandomNum).toFloat()
        }

        }