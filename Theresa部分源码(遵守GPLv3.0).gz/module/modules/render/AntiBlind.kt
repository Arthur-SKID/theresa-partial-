
package cn.theresa.features.module.modules.render

import cn.theresa.features.module.manager.Module
import cn.theresa.features.module.manager.ModuleCategory
import cn.theresa.features.module.manager.ModuleInfo
import cn.theresa.value.BoolValue

@ModuleInfo(name = "AntiBlind", spacedName = "Anti Blind", description = "Cancels blindness effects.", category = ModuleCategory.RENDER, cnName = "反失明")
class AntiBlind : Module() {
    val confusionEffect = BoolValue("Confusion", true)
    val pumpkinEffect = BoolValue("Pumpkin", true)
    val fireEffect = BoolValue("Fire", false)
    val scoreBoard = BoolValue("Scoreboard", false)
    val bossHealth = BoolValue("Boss-Health", true)
}