
package cn.theresa.features.module.modules.movement.speeds.other;

import cn.theresa.ClientMain;
import cn.theresa.features.module.modules.movement.InvMove;
import cn.theresa.event.MoveEvent;
import cn.theresa.features.module.modules.movement.speeds.SpeedMode;
import cn.theresa.utils.MovementUtils;
import net.minecraft.client.gui.GuiChat;
import net.minecraft.client.gui.GuiIngameMenu;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.settings.GameSettings;

public class Legit extends SpeedMode {

    public Legit() {
        super("Legit");
    }

    @Override
    public void onMotion() {
        final InvMove invMove = ClientMain.moduleManager.getModule(InvMove.class);
        mc.gameSettings.keyBindJump.pressed = ((MovementUtils.isMoving() || GameSettings.isKeyDown(mc.gameSettings.keyBindJump)) && (mc.inGameHasFocus || (invMove.getState() && !(mc.currentScreen instanceof GuiChat || mc.currentScreen instanceof GuiIngameMenu) || !(mc.currentScreen instanceof GuiContainer))));
    }

    @Override
    public void onUpdate() {
        
    }

    @Override
    public void onMove(MoveEvent event) {
    }
}
