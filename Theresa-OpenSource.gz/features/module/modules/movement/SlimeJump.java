
package cn.theresa.features.module.modules.movement;

import cn.theresa.event.EventTarget;
import cn.theresa.event.JumpEvent;
import cn.theresa.features.module.manager.Module;
import cn.theresa.features.module.manager.ModuleCategory;
import cn.theresa.features.module.manager.ModuleInfo;
import cn.theresa.utils.block.BlockUtils;
import cn.theresa.value.FloatValue;
import cn.theresa.value.ListValue;
import net.minecraft.block.BlockSlime;

@ModuleInfo(name = "SlimeJump", spacedName = "Slime Jump", description = "Allows you to to jump higher on slime blocks.", category = ModuleCategory.MOVEMENT,cnName = "粘液块跳跃")
public class SlimeJump extends Module {

    private final FloatValue motionValue = new FloatValue("Motion", 0.42F, 0.2F, 1F);
    private final ListValue modeValue = new ListValue("Mode", new String[] {"Set", "Add"}, "Add");

    @EventTarget
    public void onJump(JumpEvent event) {
        if(mc.thePlayer != null && mc.theWorld != null && BlockUtils.getBlock(mc.thePlayer.getPosition().down()) instanceof BlockSlime) {
            event.cancelEvent();

            switch(modeValue.get().toLowerCase()) {
                case "set":
                    mc.thePlayer.motionY = motionValue.get();
                    break;
                case "add":
                    mc.thePlayer.motionY += motionValue.get();
                    break;
            }
        }
    }
}