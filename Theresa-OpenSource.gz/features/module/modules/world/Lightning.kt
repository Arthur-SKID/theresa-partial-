
package cn.theresa.features.module.modules.world

import cn.theresa.ClientMain
import cn.theresa.ui.client.hud.element.elements.Notification
import cn.theresa.event.EventTarget
import cn.theresa.event.PacketEvent
import cn.theresa.features.module.manager.Module
import cn.theresa.features.module.manager.ModuleCategory
import cn.theresa.features.module.manager.ModuleInfo
import cn.theresa.utils.ClientUtils
import cn.theresa.value.BoolValue
import net.minecraft.network.play.server.S2CPacketSpawnGlobalEntity

import kotlin.math.roundToInt

@ModuleInfo(name = "Lightning", description = "Checks for lightning spawn and notify you.", category = ModuleCategory.WORLD, cnName = "雷电定位")
class Lightning : Module() {
    val chatValue = BoolValue("Chat", true)
    val notifValue = BoolValue("Notification", false)

    @EventTarget
    fun onPacket(event: PacketEvent) {
        val packet = event.packet
        if (packet is S2CPacketSpawnGlobalEntity && packet.func_149053_g() == 1) {
            val x = packet.func_149051_d() / 32.0
            val y = packet.func_149050_e() / 32.0
            val z = packet.func_149049_f() / 32.0
            val dist = mc.thePlayer.getDistance(x, mc.thePlayer.entityBoundingBox.minY, z).roundToInt()

            if (chatValue.get())
                ClientUtils.displayChatMessage("§7[§6§lLightning§7] §fDetected lightning at §a$x $y $z §7($dist blocks away)")
            
            if (notifValue.get())
                ClientMain.hud.addNotification(Notification("Lightning [$x $y $z] ($dist blocks away)", Notification.Type.WARNING, 3000L))
        }
    }
}