
package cn.theresa.features.module.modules.misc

import cn.theresa.features.module.manager.Module
import cn.theresa.features.module.manager.ModuleCategory
import cn.theresa.features.module.manager.ModuleInfo

@ModuleInfo(name = "HoverDetails", spacedName = "Hover Details", description = "Allows you to see onclick action and value of chat message components when hovered.", category = ModuleCategory.MISC, cnName = "梯子悬停")
class HoverDetails : Module()