
package cn.theresa.features.module.modules.render

import cn.theresa.event.EventTarget
import cn.theresa.event.Render3DEvent
import cn.theresa.features.module.manager.Module
import cn.theresa.features.module.manager.ModuleCategory
import cn.theresa.features.module.manager.ModuleInfo
import cn.theresa.utils.render.RenderUtils
import net.minecraft.entity.item.EntityTNTPrimed
import java.awt.Color

@ModuleInfo(name = "TNTESP", spacedName = "TNT ESP", description = "Allows you to see ignited TNT blocks through walls.", category = ModuleCategory.RENDER, cnName = "TNT显示")
class TNTESP : Module() {

    @EventTarget
    fun onRender3D(event : Render3DEvent) {
        mc.theWorld.loadedEntityList.filterIsInstance<EntityTNTPrimed>().forEach { RenderUtils.drawEntityBox(it, Color.RED, false) }
    }
}