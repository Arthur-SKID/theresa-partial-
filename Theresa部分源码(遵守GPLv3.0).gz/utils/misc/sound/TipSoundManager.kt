
package cn.theresa.utils.misc.sound

import cn.theresa.ClientMain
import cn.theresa.utils.FileUtils
import java.io.File

class TipSoundManager {
    var enableSound : TipSoundPlayer
    var disableSound : TipSoundPlayer

    var autoplaySound : TipSoundPlayer
    init {
        val enableSoundFile = File(ClientMain.fileManager.soundsDir, "enable.wav")
        val disableSoundFile = File(ClientMain.fileManager.soundsDir, "disable.wav")
        val autoplaySoundFile = File(ClientMain.fileManager.soundsDir,"nevergonnagiveyouup")

        if (!enableSoundFile.exists())
            FileUtils.unpackFile(enableSoundFile, "assets/minecraft/theresa/sound/enable.wav")
        if (!disableSoundFile.exists())
            FileUtils.unpackFile(disableSoundFile, "assets/minecraft/theresa/sound/disable.wav")
        if (!autoplaySoundFile.exists())
            FileUtils.unpackFile(enableSoundFile,"assets/minecraft/theresa/sound/nevergonnagiveyouup.wav")

        enableSound = TipSoundPlayer(enableSoundFile)
        disableSound = TipSoundPlayer(disableSoundFile)
        autoplaySound = TipSoundPlayer(autoplaySoundFile)
    }
}