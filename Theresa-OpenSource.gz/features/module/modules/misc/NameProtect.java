
package cn.theresa.features.module.modules.misc;

import cn.theresa.ClientMain;
import cn.theresa.event.EventTarget;
import cn.theresa.event.TextEvent;
import cn.theresa.features.module.manager.Module;
import cn.theresa.features.module.manager.ModuleCategory;
import cn.theresa.features.module.manager.ModuleInfo;
import cn.theresa.file.configs.FriendsConfig;
import cn.theresa.utils.ClientUtils;
import cn.theresa.utils.misc.StringUtils;
import cn.theresa.utils.render.ColorUtils;
import cn.theresa.value.BoolValue;
import cn.theresa.value.TextValue;
import net.minecraft.client.network.NetworkPlayerInfo;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.util.ResourceLocation;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;

@ModuleInfo(name = "NameProtect", spacedName = "Name Protect", description = "Changes player names client-side.", category = ModuleCategory.MISC,cnName = "假名字")
public class NameProtect extends Module {

    private final TextValue fakeNameValue = new TextValue("FakeName", "&cMe");
    private final TextValue allFakeNameValue = new TextValue("AllPlayersFakeName", "Censored");
    public final BoolValue selfValue = new BoolValue("Yourself", true);
    public final BoolValue tagValue = new BoolValue("Tag", false);
    public final BoolValue allPlayersValue = new BoolValue("AllPlayers", false);
    public final BoolValue skinProtectValue = new BoolValue("SkinProtect", false);
    public final BoolValue customSkinValue = new BoolValue("CustomSkin", false, () -> skinProtectValue.get());

    public ResourceLocation skinImage;

    public NameProtect() {
        File skinFile = new File(ClientMain.fileManager.dir, "cskin.png");
        if (skinFile.isFile()) {
            try {
                final BufferedImage bufferedImage = ImageIO.read(new FileInputStream(skinFile));

                if (bufferedImage == null)
                    return;

                skinImage = new ResourceLocation(ClientMain.NAME.toLowerCase() + "/cskin.png");

                mc.getTextureManager().loadTexture(skinImage, new DynamicTexture(bufferedImage));
                ClientUtils.getLogger().info("Loaded custom skin for NameProtect.");
            } catch (final Exception e) {
                ClientUtils.getLogger().error("Failed to load custom skin.", e);
            }
        }
    }

    @EventTarget
    public void onText(final TextEvent event) {
        if (mc.thePlayer == null || event.getText().contains("§8[§9§l" + ClientMain.NAME + "§8] §3") || event.getText().startsWith("/") || event.getText().startsWith(ClientMain.commandManager.getPrefix() + ""))
            return;

        for (final FriendsConfig.Friend friend : ClientMain.fileManager.friendsConfig.getFriends())
            event.setText(StringUtils.replace(event.getText(), friend.getPlayerName(), ColorUtils.translateAlternateColorCodes(friend.getAlias()) + "§f"));

        event.setText(StringUtils.replace(
            event.getText(), 
            mc.thePlayer.getName(), 
            (selfValue.get() ? (tagValue.get() ? StringUtils.injectAirString(mc.thePlayer.getName()) + " §7(§r" + ColorUtils.translateAlternateColorCodes(fakeNameValue.get() + "§r§7)") : ColorUtils.translateAlternateColorCodes(fakeNameValue.get()) + "§r") : mc.thePlayer.getName())
        ));

        if(allPlayersValue.get())
            for(final NetworkPlayerInfo playerInfo : mc.getNetHandler().getPlayerInfoMap())
                event.setText(StringUtils.replace(event.getText(), playerInfo.getGameProfile().getName(), ColorUtils.translateAlternateColorCodes(allFakeNameValue.get()) + "§f"));
    }

}
