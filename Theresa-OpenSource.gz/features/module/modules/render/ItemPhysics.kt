
package cn.theresa.features.module.modules.render

import cn.theresa.features.module.*
import cn.theresa.features.module.manager.Module
import cn.theresa.features.module.manager.ModuleCategory
import cn.theresa.features.module.manager.ModuleInfo
import cn.theresa.value.FloatValue

@ModuleInfo(name = "ItemPhysics", spacedName = "Item Physics", description = "newton hits", category = ModuleCategory.RENDER, cnName = "物理掉落")
class ItemPhysics : Module() {
    val itemWeight = FloatValue("Weight", 0.5F, 0F, 1F, "x")
    override val tag: String?
        get() = "${itemWeight.get()}"
}
