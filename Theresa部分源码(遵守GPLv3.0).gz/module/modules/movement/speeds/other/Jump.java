
package cn.theresa.features.module.modules.movement.speeds.other;

import cn.theresa.ClientMain;
import cn.theresa.features.module.modules.movement.Speed;
import cn.theresa.event.MoveEvent;
import cn.theresa.features.module.modules.movement.speeds.SpeedMode;
import cn.theresa.utils.MovementUtils;

public class Jump extends SpeedMode {

    public Jump() {
        super("Jump");
    }

    @Override
    public void onMotion() {

    }

    @Override
    public void onUpdate() {
        
        final Speed speed = ClientMain.moduleManager.getModule(Speed.class);

        if(speed == null)
            return;
        if(MovementUtils.isMoving() && mc.thePlayer.onGround && !mc.gameSettings.keyBindJump.isKeyDown() && !(mc.thePlayer.isInWater() || mc.thePlayer.isInLava()) && mc.thePlayer.jumpTicks == 0) {
            mc.thePlayer.jump();
            mc.thePlayer.jumpTicks = 10;
        }
        if (speed.jumpStrafe.get() && MovementUtils.isMoving() && !mc.thePlayer.onGround && !(mc.thePlayer.isInWater() || mc.thePlayer.isInLava())) 
            MovementUtils.strafe();
    }

    @Override
    public void onMove(MoveEvent event) {
    }
}
