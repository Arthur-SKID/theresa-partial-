
package cn.theresa.features.module.modules.combat

import cn.theresa.features.module.manager.Module
import cn.theresa.features.module.manager.ModuleCategory
import cn.theresa.features.module.manager.ModuleInfo
import cn.theresa.value.FloatValue

@ModuleInfo(name = "HitBox", spacedName = "Hit Box", description = "Makes hitboxes of targets bigger.", category = ModuleCategory.COMBAT, cnName = "修改碰撞箱")
class HitBox : Module() {

    val sizeValue = FloatValue("Size", 0.4F, 0F, 1F)

}