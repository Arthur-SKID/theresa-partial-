/*
 * Theresa Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge(OLD).
 * https://github.com/WYSI-Foundation/LiquidBouncePlus/
 * LZTN
 * This code belongs to WYSI-Foundation. Please give credits when using this in your repository.
 */
package cn.theresa.features.module.modules.render;

import cn.theresa.features.module.manager.Module;
import cn.theresa.features.module.manager.ModuleCategory;
import cn.theresa.features.module.manager.ModuleInfo;
import cn.theresa.value.IntegerValue;
import cn.theresa.value.FloatValue;
import cn.theresa.value.ListValue;

@ModuleInfo(name = "EnchantEffect", spacedName = "Enchant Effect", description = "qwq", category = ModuleCategory.RENDER,cnName = "多彩的附魔")
public class EnchantEffect extends Module {
    public IntegerValue redValue = new IntegerValue("Red", 255, 0, 255);
    public IntegerValue greenValue = new IntegerValue("Green", 0, 0, 255);
    public IntegerValue blueValue = new IntegerValue("Blue", 0, 0, 255);
    public ListValue modeValue = new ListValue("Mode", new String[]{"Custom","Rainbow","Sky","Mixer"}, "Custom");
    public IntegerValue rainbowSpeedValue = new IntegerValue("Seconds", 1, 1, 6);
    public IntegerValue rainbowDelayValue = new IntegerValue("Delay", 5, 0, 10);
    public FloatValue rainbowSatValue = new FloatValue("Saturation", 1.0f, 0.0f, 1.0f);
    public FloatValue rainbowBrgValue = new FloatValue("Brightness", 1.0f, 0.0f, 1.0f);
}