
package cn.theresa.features.module.modules.combat

import cn.theresa.event.EventTarget
import cn.theresa.event.MotionEvent
import cn.theresa.features.module.manager.Module
import cn.theresa.features.module.manager.ModuleCategory
import cn.theresa.features.module.manager.ModuleInfo
import cn.theresa.value.BoolValue
import cn.theresa.value.FloatValue
import cn.theresa.value.IntegerValue
import net.minecraft.client.settings.GameSettings
import net.minecraft.entity.item.EntityTNTPrimed
import net.minecraft.item.ItemSword

@ModuleInfo(name = "TNTBlock", spacedName = "TNT Block", description = "Automatically blocks with your sword when TNT around you explodes.", category = ModuleCategory.COMBAT, cnName = "自动格挡TNT")
class TNTBlock : Module() {
    private val fuseValue = IntegerValue("Fuse", 10, 0, 80)
    private val rangeValue = FloatValue("Range", 9F, 1F, 20F)
    private val autoSwordValue = BoolValue("AutoSword", true)
    private var blocked = false

    @EventTarget
    fun onMotionUpdate(event: MotionEvent) {
        mc.thePlayer ?: return
        mc.theWorld ?: return

        for (entity in mc.theWorld.loadedEntityList) {
            if (entity is EntityTNTPrimed && mc.thePlayer.getDistanceToEntity(entity) <= rangeValue.get()) {
                if (entity.fuse <= fuseValue.get()) {
                    if (autoSwordValue.get()) {
                        var slot = -1
                        var bestDamage = 1f
                        for (i in 0..8) {
                            val itemStack = mc.thePlayer.inventory.getStackInSlot(i)

                            if (itemStack != null && itemStack.getItem() is ItemSword) {
                                val itemDamage = (itemStack.getItem() as ItemSword).damageVsEntity + 4F;

                                if (itemDamage > bestDamage) {
                                    bestDamage = itemDamage
                                    slot = i
                                }
                            }
                        }

                        if (slot != -1 && slot != mc.thePlayer.inventory.currentItem) {
                            mc.thePlayer.inventory.currentItem = slot
                            mc.playerController.updateController()
                        }
                    }
                    if (mc.thePlayer.getHeldItem() != null && mc.thePlayer.getHeldItem().getItem() is ItemSword) {
                        mc.gameSettings.keyBindUseItem.pressed = true
                        blocked = true
                    }
                    return
                }
            }
        }

        if (blocked && !GameSettings.isKeyDown(mc.gameSettings.keyBindUseItem)) {
            mc.gameSettings.keyBindUseItem.pressed = false
            blocked = false
        }
    }
}