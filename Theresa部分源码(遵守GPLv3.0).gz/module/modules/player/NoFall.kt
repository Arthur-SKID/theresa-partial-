/*
 * Theresa Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge.
 * https://github.com/WYSI-Foundation/LiquidBouncePlus/
 *
 * the entirety of this was pasted and modified from FDPClient, give 'em credits when pasting anything here.
 */
package cn.theresa.features.module.modules.player

import cn.theresa.ClientMain
import cn.theresa.event.EventTarget
import cn.theresa.event.PacketEvent
import cn.theresa.features.module.manager.Module
import cn.theresa.features.module.manager.ModuleCategory
import cn.theresa.features.module.manager.ModuleInfo
import cn.theresa.features.module.modules.movement.Fly
import cn.theresa.features.module.modules.render.FreeCam
import cn.theresa.utils.MovementUtils
import cn.theresa.utils.PacketUtils
import cn.theresa.utils.block.BlockUtils
import cn.theresa.utils.timer.MSTimer
import cn.theresa.value.ListValue
import net.minecraft.block.BlockLiquid
import net.minecraft.network.play.client.C03PacketPlayer
import net.minecraft.network.play.client.C03PacketPlayer.C04PacketPlayerPosition
import net.minecraft.network.play.server.S08PacketPlayerPosLook
import net.minecraft.util.AxisAlignedBB
import java.util.*
import kotlin.math.roundToInt

@ModuleInfo(name = "NoFall", spacedName = "No Fall", description = "Prevents you from taking fall damage.", category = ModuleCategory.PLAYER, cnName = "无掉落伤害")
class NoFall : Module() {
    val typeValue = ListValue("Type", arrayOf("Edit", "Packet", "CubeCraft", "Hypixel", "Verus", "Medusa", "Matrix", "Vulcan"), "Edit")
    val editMode = ListValue("Edit-Mode", arrayOf("Always", "Default", "Smart", "NoGround", "Damage"), "Always") { typeValue.get().equals("edit", true) }
    private val packetMode = ListValue("Packet-Mode", arrayOf("Default", "Smart"), "Default") { typeValue.get().equals("packet", true) }
    private val hypixelMode = ListValue("Hypixel-Mode", arrayOf("Default", "Packet", "New"), "Default") { typeValue.get().equals("hypixel", true) }
    private val matrixMode = ListValue("Matrix-Mode", arrayOf("Old", "6.2.x", "6.6.3"), "Old") { typeValue.get().equals("matrix", true) }

    private val aac4FlagCooldown = MSTimer()

    private var oldaacState = 0
   
    private var aac4Fakelag = false
    private var aac4FlagCount = 0
    
    private var aac5doFlag = false
    private var aac5Check = false
    private var aac5Timer = 0
    private val aac4Packets = mutableListOf<C03PacketPlayer>()

    private var matrixFalling = false
    private var matrixCanSpoof = false
    private var matrixFallTicks = 0
    private var matrixLastMotionY = 0.0
    private var matrixFlagWait = 0
    private var matrixSend = false

    private var isDmgFalling = false
    private var jumped = false
    private var modifiedTimer = false
    private var packetModify = false
    private var needSpoof = false
    private var doSpoof = false
    private var nextSpoof = false
    private var vulcantNoFall = true
    private var vulcanNoFall = false
    private var lastFallDistRounded = 0

    override fun onEnable() {
        aac4FlagCount = 0
        aac4Fakelag = false
        aac5Check = false
        packetModify = false
        aac4Packets.clear()
        needSpoof = false
        aac5doFlag = false
        aac5Timer = 0
        lastFallDistRounded = 0
        oldaacState = 0
        matrixFalling = false
        matrixCanSpoof = false
        matrixFallTicks = 0
        matrixLastMotionY = 0.0
        isDmgFalling = false
        matrixFlagWait = 0
        aac4FlagCooldown.reset()
        nextSpoof = false
        doSpoof = false
    }
    
    override fun onDisable() {
        matrixSend = false
        aac4FlagCount = 0
        aac4Fakelag = false
        aac5Check = false
        packetModify = false
        aac4Packets.clear()
        needSpoof = false
        aac5doFlag = false
        aac5Timer = 0
        lastFallDistRounded = 0
        oldaacState = 0
        matrixFalling = false
        matrixCanSpoof = false
        matrixFallTicks = 0
        matrixLastMotionY = 0.0
        isDmgFalling = false
        matrixFlagWait = 0
        aac4FlagCooldown.reset()
        mc.timer.timerSpeed = 1.0f
    }

    @EventTarget
    fun onWorld() {
        vulcantNoFall = true
        vulcanNoFall = false
    }

    @EventTarget(ignoreCondition = true)
    fun onUpdate() {
        if (modifiedTimer) {
            mc.timer.timerSpeed = 1.0F
            modifiedTimer = false
        }

        if (mc.thePlayer.onGround)
            jumped = false

        if (mc.thePlayer.motionY > 0)
            jumped = true

        if (!state || ClientMain.moduleManager[FreeCam::class.java]!!.state
            || mc.thePlayer.isSpectator || mc.thePlayer.capabilities.allowFlying || mc.thePlayer.capabilities.disableDamage)
            return

        if (!ClientMain.moduleManager[Fly::class.java]!!.state && !MovementUtils.isBlockUnder()) return

        if (BlockUtils.collideBlock(mc.thePlayer.entityBoundingBox) { it is BlockLiquid } || BlockUtils.collideBlock(AxisAlignedBB(mc.thePlayer.entityBoundingBox.maxX, mc.thePlayer.entityBoundingBox.maxY, mc.thePlayer.entityBoundingBox.maxZ, mc.thePlayer.entityBoundingBox.minX, mc.thePlayer.entityBoundingBox.minY - 0.01, mc.thePlayer.entityBoundingBox.minZ)) { it is BlockLiquid })
            return

        if (matrixFlagWait > 0) {
            if (matrixFlagWait-- == 0)
                mc.timer.timerSpeed = 1F
        }

        when (typeValue.get().lowercase(Locale.getDefault())) {
            "packet" -> when (packetMode.get().lowercase(Locale.getDefault())) {
                "default" -> {
                    if (mc.thePlayer.fallDistance > 2F)
                        mc.netHandler.addToSendQueue(C03PacketPlayer(true))
                }
                "smart" -> {
                    if (mc.thePlayer.fallDistance - mc.thePlayer.motionY > 3f) {
                        mc.netHandler.addToSendQueue(C03PacketPlayer(true))
                        mc.thePlayer.fallDistance = 0f
                    }
                }
            }
            "cubecraft" -> {
                if (mc.thePlayer.fallDistance > 2F) {
                    mc.thePlayer.onGround = true
                    mc.netHandler.addToSendQueue(C03PacketPlayer(true))
                }
            }
            "verus" -> {
                if (mc.thePlayer.fallDistance - mc.thePlayer.motionY > 3F) {
                    mc.thePlayer.motionY = 0.0
                    mc.thePlayer.motionX *= 0.5
                    mc.thePlayer.motionX *= 0.5
                    mc.thePlayer.fallDistance = 0F
                    needSpoof = true
                }
            }
            "matrix" -> when (matrixMode.get().lowercase(Locale.getDefault())) {
                "old" -> {
                    if (mc.thePlayer.fallDistance > 3)
                        isDmgFalling = true
                }
                "6.6.3" -> {
                    if (mc.thePlayer.fallDistance - mc.thePlayer.motionY > 3F) {
                        mc.thePlayer.fallDistance = 0.0f
                        matrixSend = true
                        mc.timer.timerSpeed = 0.5f
                        modifiedTimer = true
                    }
                }
                "6.2.x" -> {
                    if (matrixFalling) {
                        mc.thePlayer.motionX = 0.0
                        mc.thePlayer.motionZ = 0.0
                        mc.thePlayer.jumpMovementFactor = 0f
                        if (mc.thePlayer.onGround) 
                            matrixFalling = false
                    }
                    if (mc.thePlayer.fallDistance - mc.thePlayer.motionY > 3F) {
                        matrixFalling = true
                        if (matrixFallTicks == 0) 
                            matrixLastMotionY = mc.thePlayer.motionY
                        mc.thePlayer.motionY = 0.0
                        mc.thePlayer.motionX = 0.0
                        mc.thePlayer.motionZ = 0.0
                        mc.thePlayer.jumpMovementFactor = 0f
                        mc.thePlayer.fallDistance = 3.2f
                        if (matrixFallTicks in 8..9) 
                            matrixCanSpoof = true
                        matrixFallTicks++
                    }
                    if (matrixFallTicks > 12 && !mc.thePlayer.onGround) {
                        mc.thePlayer.motionY = matrixLastMotionY
                        mc.thePlayer.fallDistance = 0f
                        matrixFallTicks = 0
                        matrixCanSpoof = false
                    }
                }
            }
            "edit" -> if (editMode.get().equals("smart", true)) {
                if (mc.thePlayer.fallDistance.toInt() / 3 > lastFallDistRounded) {
                    lastFallDistRounded = mc.thePlayer.fallDistance.toInt() / 3
                    packetModify = true
                }
                if (mc.thePlayer.onGround)
                    lastFallDistRounded = 0
            }
            "hypixel" -> if (hypixelMode.get().equals("packet", true)) {
                val offset = 2.5
                if (!mc.thePlayer.onGround && mc.thePlayer.fallDistance - matrixFallTicks * offset >= 0.0) {
                    mc.netHandler.addToSendQueue(C03PacketPlayer(true))
                    matrixFallTicks++
                } else if (mc.thePlayer.onGround)
                    matrixFallTicks = 1
            }
            "vulcan" -> {
                if (!vulcanNoFall && mc.thePlayer.fallDistance > 3.25)
                    vulcanNoFall = true
                if (vulcanNoFall && vulcantNoFall && mc.thePlayer.onGround)
                    vulcantNoFall = false
                if (vulcantNoFall) return // Possible flag
                if (nextSpoof) {
                    mc.thePlayer.motionY = -0.1
                    mc.thePlayer.fallDistance = -0.1F
                    MovementUtils.strafe(0.3F)
                    nextSpoof = false
                }
                if (mc.thePlayer.fallDistance > 3.5625F) {
                    mc.thePlayer.fallDistance = 0F
                    doSpoof = true
                    nextSpoof = true
                }
            }
        }
    }

    @EventTarget
    fun onMotion() {
        if (!ClientMain.moduleManager[Fly::class.java]!!.state && !MovementUtils.isBlockUnder()) return

    }

    @EventTarget
    fun onPacket(event: PacketEvent) {
        mc.thePlayer ?: return

        if (!ClientMain.moduleManager[Fly::class.java]!!.state && !MovementUtils.isBlockUnder()) return

        val packet = event.packet
        if (packet is S08PacketPlayerPosLook) {
            if (typeValue.get().equals("matrix", true) && matrixMode.get().equals("old", true) && matrixFlagWait > 0) {
                matrixFlagWait = 0
                mc.timer.timerSpeed = 1.0F
                event.cancelEvent()
            }
        }

        if (packet is C03PacketPlayer) {
            if (matrixSend) {
                matrixSend = false
                event.cancelEvent()
                PacketUtils.sendPacketNoEvent(C04PacketPlayerPosition(packet.x, packet.y, packet.z, true))
                PacketUtils.sendPacketNoEvent(C04PacketPlayerPosition(packet.x, packet.y, packet.z, false))
            } 
            
            if (doSpoof) {
                packet.onGround = true
                doSpoof = false
                packet.y = (mc.thePlayer.posY * 2).roundToInt().toDouble() / 2
                mc.thePlayer.setPosition(mc.thePlayer.posX, packet.y, mc.thePlayer.posZ)
            }

            if (typeValue.get().equals("edit", true)) {
                val edits = editMode.get()

                if (edits.equals("always", true)
                    || (edits.equals("default", true) && mc.thePlayer.fallDistance > 2.5F)
                    || (edits.equals("damage", true) && mc.thePlayer.fallDistance > 3.5F)
                    || (edits.equals("smart", true) && packetModify)) {
                    packet.onGround = true
                    packetModify = false
                }

                if (edits.equals("noground", true))
                    packet.onGround = false
            }

            if (typeValue.get().equals("medusa", true) && mc.thePlayer.fallDistance > 2.3F) {
                event.cancelEvent()
                PacketUtils.sendPacketNoEvent(C03PacketPlayer(true))
                mc.thePlayer.fallDistance = 0F
            }

            if (typeValue.get().equals("hypixel", true)) {
                when (hypixelMode.get().lowercase(Locale.getDefault())) {
                    "default" -> if (mc.thePlayer.fallDistance > 1.5) {
                        packet.onGround = mc.thePlayer.ticksExisted % 2 == 0
                    }
                    "new" -> if (mc.thePlayer.fallDistance > 2.5F && mc.thePlayer.ticksExisted % 2 == 0) {
                        packet.onGround = true
                        packet.isMoving = false
                    }
                }
            }

            if (typeValue.get().equals("verus", true) && needSpoof) {
                packet.onGround = true
                needSpoof = false
            }

            if (typeValue.get().equals("matrix", true) && matrixMode.get().equals("6.2.x", true) && matrixCanSpoof) {
                packet.onGround = true
                matrixCanSpoof = false
            }

            if (isDmgFalling && ((typeValue.get().equals("matrix", true) && matrixMode.get().equals("old", true)))) {
                if (packet.onGround && mc.thePlayer.onGround) {
                    matrixFlagWait = 2
                    isDmgFalling = false
                    event.cancelEvent()
                    mc.thePlayer.onGround = false
                    mc.netHandler.addToSendQueue(C04PacketPlayerPosition(packet.x, packet.y - 256, packet.z, false))
                    mc.netHandler.addToSendQueue(C04PacketPlayerPosition(packet.x, (-10).toDouble() , packet.z, true))
                    mc.timer.timerSpeed = 0.18f
                    modifiedTimer = true
                }
            }
        }
    }

    @EventTarget
    fun onMove() {
        if (!ClientMain.moduleManager[Fly::class.java]!!.state && !MovementUtils.isBlockUnder()) return

        if (BlockUtils.collideBlock(mc.thePlayer.entityBoundingBox) { it is BlockLiquid } || BlockUtils.collideBlock(AxisAlignedBB(mc.thePlayer.entityBoundingBox.maxX, mc.thePlayer.entityBoundingBox.maxY, mc.thePlayer.entityBoundingBox.maxZ, mc.thePlayer.entityBoundingBox.minX, mc.thePlayer.entityBoundingBox.minY - 0.01, mc.thePlayer.entityBoundingBox.minZ)) { it is BlockLiquid })
            return

    }

    @EventTarget(ignoreCondition = true)
    fun onJump() {
        jumped = true
    }

    override val tag: String
        get() = typeValue.get()
}
