
package cn.theresa.features.module.modules.world

import cn.theresa.features.module.manager.Module
import cn.theresa.features.module.manager.ModuleCategory
import cn.theresa.features.module.manager.ModuleInfo
import cn.theresa.value.IntegerValue

@ModuleInfo(name = "FastPlace", spacedName = "Fast Place", description = "Allows you to place blocks faster.", category = ModuleCategory.WORLD, cnName = "快速使用")
class FastPlace : Module() {
    val speedValue = IntegerValue("Speed", 0, 0, 4)
}
