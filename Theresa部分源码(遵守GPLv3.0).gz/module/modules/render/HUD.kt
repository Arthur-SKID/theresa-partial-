
package cn.theresa.features.module.modules.render

import cn.theresa.ClientMain
import cn.theresa.event.*
import cn.theresa.features.module.manager.Module
import cn.theresa.features.module.manager.ModuleCategory
import cn.theresa.features.module.manager.ModuleInfo
import cn.theresa.ui.client.hud.designer.GuiHudDesigner
import cn.theresa.ui.font.Fonts
import cn.theresa.utils.AnimationUtils
import cn.theresa.utils.render.RenderUtils
import cn.theresa.value.*
import net.minecraft.client.Minecraft
import net.minecraft.client.gui.ScaledResolution
import java.text.SimpleDateFormat
import java.util.*

@ModuleInfo(name = "HUD", description = "Toggles visibility of the HUD.", category = ModuleCategory.RENDER, array = false, cnName = "界面")
class HUD : Module() {
    val globalFont = BoolValue("GlobalFont", false)
    val tabHead = BoolValue("Tab-HeadOverlay", true)
    val animHotbarValue = BoolValue("AnimatedHotbar", true)
    val blackHotbarValue = BoolValue("BlackHotbar", true)
    val inventoryParticle = BoolValue("InventoryParticle", false)
    val fontChatValue = BoolValue("FontChat", false)
    val fontType = FontValue("Font", Fonts.font40) { fontChatValue.get() }
    val chatRectValue = BoolValue("ChatRect", true)
    val chatCombineValue = BoolValue("ChatCombine", true)
    val chatAnimationValue = BoolValue("ChatAnimation", true)
    val chatAnimationSpeedValue = FloatValue("Chat-AnimationSpeed", 0.1F, 0.01F, 0.1F)

    private val toggleMessageValue = BoolValue("DisplayToggleMessage", false)
    private val toggleSoundValue = ListValue("ToggleSound", arrayOf("None", "Default", "Custom"), "Default")
    private val toggleVolumeValue = IntegerValue("ToggleVolume", 100, 0, 100, { toggleSoundValue.get().equals("custom", true) })
    val containerBackground = BoolValue("Container-Background", false)
    val containerButton = ListValue("Container-Button", arrayOf("TopLeft", "TopRight", "Off"), "TopLeft")
    val invEffectOffset = BoolValue("InvEffect-Offset", false)
    val domainValue = "ft.theresa.cloud"

    private var hotBarX = 0F

    @EventTarget
    fun onRender2D(event: Render2DEvent) {
        val fpsandping =
            "FPS: " + Minecraft.getDebugFPS() + " Ping: " + Objects.requireNonNull(mc.netHandler).getPlayerInfo(
                mc.thePlayer.uniqueID
            ).getResponseTime()
        val cords =
            "X:" + mc.thePlayer.posX.toInt() + " Y:" + mc.thePlayer.posY.toInt() + " Z:" + mc.thePlayer.posZ.toInt()
        val time: String = SimpleDateFormat("HH:mm").format(Calendar.getInstance().getTime())
        val date: String = SimpleDateFormat("dd/MM/yyyy").format(Calendar.getInstance().getTime())
        val scaledResolution = ScaledResolution(mc)

        Fonts.fontSFUI35.drawString(
            fpsandping,
            3f,
            scaledResolution.scaledHeight - 17f,
            -1,
            true
        )
        Fonts.fontSFUI35.drawString(
            cords,
            3f,
            scaledResolution.scaledHeight - 8f,
            -1,
            true
        )
        Fonts.fontSFUI35.drawString(
            time,
            scaledResolution.scaledWidth - Fonts.fontSFUI35.getStringWidth(time) - 16f,
            scaledResolution.scaledHeight - 17.5f,
            -1,
            true
        )
        Fonts.fontSFUI35.drawString(
            date,
            scaledResolution.scaledWidth - Fonts.fontSFUI35.getStringWidth(date) - 7f,
            scaledResolution.scaledHeight - 8.5f,
            -1,
            true
        )


        if (mc.currentScreen is GuiHudDesigner) return
        ClientMain.hud.render(false)
    }

    @EventTarget(ignoreCondition = true)
    fun onTick(event: TickEvent) {
        if (ClientMain.moduleManager.shouldNotify != toggleMessageValue.get())
            ClientMain.moduleManager.shouldNotify = toggleMessageValue.get()

        if (ClientMain.moduleManager.toggleSoundMode != toggleSoundValue.values.indexOf(toggleSoundValue.get()))
            ClientMain.moduleManager.toggleSoundMode = toggleSoundValue.values.indexOf(toggleSoundValue.get())

        if (ClientMain.moduleManager.toggleVolume != toggleVolumeValue.get().toFloat())
            ClientMain.moduleManager.toggleVolume = toggleVolumeValue.get().toFloat()
    }

    @EventTarget
    fun onUpdate(event: UpdateEvent?) {
        ClientMain.hud.update()
    }

    @EventTarget
    fun onKey(event: KeyEvent) {
        ClientMain.hud.handleKey('a', event.key)
    }

    fun getAnimPos(pos: Float): Float {
        if (state && animHotbarValue.get()) hotBarX = AnimationUtils.animate(pos, hotBarX, 0.02F * RenderUtils.deltaTime.toFloat())
        else hotBarX = pos

        return hotBarX
    }

    init {
        state = true
    }
}