/*
 * Theresa Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge(OLD).
 * https://github.com/WYSI-Foundation/LiquidBouncePlus/
 * LZTN
 * This code belongs to WYSI-Foundation. Please give credits when using this in your repository.
 */
package cn.theresa.features.other.command.commands

import cn.theresa.ClientMain
import cn.theresa.features.other.command.Command
import cn.theresa.features.module.modules.misc.AutoDisable.DisableEvent
import cn.theresa.utils.ClientUtils

class AutoDisableCommand : Command("autodisable", arrayOf("ad")) {

    /**
     * Execute commands with provided [args]
     */
    override fun execute(args: Array<String>) {
        if (args.size == 2) {
            when (args[1].toLowerCase()) {
                "list" -> {
                    chat("§c§lAutoDisable modules:")
                    ClientMain.moduleManager.modules.filter { it.autoDisables.size > 0 }.forEach {
                        ClientUtils.displayChatMessage("§6> §c${it.name} §7| §a${it.autoDisables.map { d -> d.name.toLowerCase() }.joinToString()}")
                    }
                    return
                }
                "clear" -> {
                    ClientMain.moduleManager.modules.filter { it.autoDisables.size > 0 }.forEach {
                        it.autoDisables.clear()
                    }
                    chat("Successfully cleared the AutoDisable list.")
                    return
                }
            }
        }
        else if (args.size > 2) {
            // Get module by name
            val module = ClientMain.moduleManager.getModule(args[1])

            if (module == null) {
                chat("Module §a§l${args[1]}§3 not found.")
                return
            }

            if (args[2].equals("clear", true)) {
                module.autoDisables.clear()
                chat("Module §a§l${module.name}§3 has been removed from AutoDisable trigger list.")
                playEdit()
                return
            }

            try {
                val disableWhen = DisableEvent.valueOf(args[2].toUpperCase())

                var added = "will now"
                if (module.autoDisables.contains(disableWhen)) {
                    if (module.autoDisables.remove(disableWhen)) {
                        added = "will no longer"
                    }
                } else {
                    module.autoDisables.add(disableWhen)
                }

                val disableType = when (disableWhen) {
                    DisableEvent.FLAG -> "when you get flagged."
                    DisableEvent.WORLD_CHANGE -> "when you change the world."
                    DisableEvent.GAME_END -> "when the game end."
                    else -> null
                }

                // Response to user
                chat("Module §a§l${module.name}§3 $added be disabled $disableType")
                playEdit()
                return
            } catch (e: IllegalArgumentException) {
                chat("§c§lWrong auto disable type!")
                chatSyntax("autodisable <module> <clear/flag/world_change/game_end>")
                return
            }
        }

        chatSyntax("autodisable <module/list> <clear/flag/world_change/game_end>")
    }

    override fun tabComplete(args: Array<String>): List<String> {
        if (args.isEmpty()) return emptyList()

        val moduleName = args[0]

        return when (args.size) {
            1 -> ClientMain.moduleManager.modules
                    .map { it.name }
                    .filter { it.startsWith(moduleName, true) }
                    .toList()
            2 -> listOf<String>("clear", "flag", "world_change", "game_end").filter { it.startsWith(args[1], true) }
            else -> emptyList()
        }
    }

}