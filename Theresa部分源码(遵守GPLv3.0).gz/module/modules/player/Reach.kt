
package cn.theresa.features.module.modules.player

import cn.theresa.features.module.manager.Module
import cn.theresa.features.module.manager.ModuleCategory
import cn.theresa.features.module.manager.ModuleInfo
import cn.theresa.value.FloatValue

@ModuleInfo(name = "Reach", description = "Increases your reach.", category = ModuleCategory.PLAYER, cnName = "长臂猿")
class Reach : Module() {

    val combatReachValue = FloatValue("CombatReach", 3.5f, 3f, 7f, "m")
    val buildReachValue = FloatValue("BuildReach", 5f, 4.5f, 7f, "m")

    val maxRange: Float
        get() {
            val combatRange = combatReachValue.get()
            val buildRange = buildReachValue.get()

            return if (combatRange > buildRange) combatRange else buildRange
        }
}
