
package cn.theresa.features.module.modules.movement;

import cn.theresa.event.EventTarget;
import cn.theresa.event.UpdateEvent;
import cn.theresa.features.module.manager.Module;
import cn.theresa.features.module.manager.ModuleCategory;
import cn.theresa.features.module.manager.ModuleInfo;
import cn.theresa.utils.block.BlockUtils;
import cn.theresa.value.FloatValue;
import net.minecraft.block.BlockLiquid;

@ModuleInfo(name = "WaterSpeed", spacedName = "Water Speed", description = "Allows you to swim faster.", category = ModuleCategory.MOVEMENT,cnName = "水中高速")
public class WaterSpeed extends Module {

    private final FloatValue speedValue = new FloatValue("Speed", 1.2F, 1.1F, 1.5F);

    @EventTarget
    public void onUpdate(UpdateEvent event) {
        if(mc.thePlayer.isInWater() && BlockUtils.getBlock(mc.thePlayer.getPosition()) instanceof BlockLiquid) {
            final float speed = speedValue.get();

            mc.thePlayer.motionX *= speed;
            mc.thePlayer.motionZ *= speed;
        }
    }
}