
package cn.theresa.utils.misc.sound

import cn.theresa.ClientMain
import cn.theresa.utils.FileUtils
import java.io.File

class TipSoundManager {
    var enableSound : TipSoundPlayer
    var disableSound : TipSoundPlayer
    var autoplaySound : TipSoundPlayer
    var autoplaySound2 : TipSoundPlayer
    init {
        val enableSoundFile = File(ClientMain.fileManager.soundsDir, "enable.wav")
        val disableSoundFile = File(ClientMain.fileManager.soundsDir, "disable.wav")
        val autoplaySoundFile = File(ClientMain.fileManager.soundsDir,"nevergonnagiveyouup")
        val autoplaySoundFile2 = File(ClientMain.fileManager.soundsDir,"riben.wav")

        if (!enableSoundFile.exists())
            FileUtils.unpackFile(enableSoundFile, "assets/minecraft/theresa/sound/enable.wav")
        if (!disableSoundFile.exists())
            FileUtils.unpackFile(disableSoundFile, "assets/minecraft/theresa/sound/disable.wav")
        if (!autoplaySoundFile.exists())
            FileUtils.unpackFile(autoplaySoundFile,"assets/minecraft/theresa/sound/nevergonnagiveyouup.wav")
        if (!autoplaySoundFile2.exists())
            FileUtils.unpackFile(autoplaySoundFile2,"assets/minecraft/theresa/sound/riben.wav")

        enableSound = TipSoundPlayer(enableSoundFile)
        disableSound = TipSoundPlayer(disableSoundFile)
        autoplaySound = TipSoundPlayer(autoplaySoundFile)
        autoplaySound2 = TipSoundPlayer(autoplaySoundFile2)
    }
}