
package cn.theresa.features.module.modules.world

import cn.theresa.features.module.manager.Module
import cn.theresa.features.module.manager.ModuleCategory
import cn.theresa.features.module.manager.ModuleInfo
import cn.theresa.value.BoolValue

@ModuleInfo(name = "NoSlowBreak", spacedName = "No Slow Break", description = "Automatically adjusts breaking speed when using modules that influence it.", category = ModuleCategory.WORLD, cnName = "断开速度")
class NoSlowBreak : Module() {
    val airValue = BoolValue("Air", true)
    val waterValue = BoolValue("Water", false)
}
