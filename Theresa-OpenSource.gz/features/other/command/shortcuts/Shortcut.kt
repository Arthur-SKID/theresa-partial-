
package cn.theresa.features.other.command.shortcuts

import cn.theresa.features.other.command.Command

class Shortcut(val name: String, val script: List<Pair<Command, Array<String>>>) : Command(name, emptyArray()) {
    /**
     * Execute commands with provided [args]
     */
    override fun execute(args: Array<String>) {
        script.forEach { it.first.execute(it.second) }
    }
}
