package cn.theresa.features.other.special

import cn.theresa.ClientMain
import cn.theresa.event.EventTarget
import cn.theresa.event.Listenable
import cn.theresa.event.KeyEvent
import cn.theresa.utils.MinecraftInstance

object MacroManager : MinecraftInstance(), Listenable {

    val macroMapping = hashMapOf<Int, String>()

    @EventTarget
    fun onKey(event: KeyEvent) {
        mc.thePlayer ?: return
        ClientMain.commandManager ?: return
        macroMapping.filter { it.key == event.key }.forEach { 
            if (it.value.startsWith(ClientMain.commandManager.prefix))
                ClientMain.commandManager.executeCommands(it.value)
            else
                mc.thePlayer.sendChatMessage(it.value) 
        }
    }

    fun addMacro(keyCode: Int, command: String) {
        macroMapping[keyCode] = command
    }

    fun removeMacro(keyCode: Int) {
        macroMapping.remove(keyCode)
    }

    override fun handleEvents(): Boolean = true

}