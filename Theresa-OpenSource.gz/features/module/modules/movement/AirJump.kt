
package cn.theresa.features.module.modules.movement

import cn.theresa.features.module.manager.Module
import cn.theresa.features.module.manager.ModuleCategory
import cn.theresa.features.module.manager.ModuleInfo

@ModuleInfo(name = "AirJump", spacedName = "Air Jump", description = "Allows you to jump in the mid air", category = ModuleCategory.MOVEMENT, cnName = "空气跳跃")
class AirJump : Module()
