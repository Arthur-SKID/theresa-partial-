
package cn.theresa.features.module.modules.movement

import cn.theresa.event.EventTarget
import cn.theresa.event.MoveEvent
import cn.theresa.features.module.manager.Module
import cn.theresa.features.module.manager.ModuleCategory
import cn.theresa.features.module.manager.ModuleInfo
import cn.theresa.value.BoolValue

@ModuleInfo(name = "SafeWalk", spacedName = "Safe Walk", description = "Prevents you from falling down as if you were sneaking.", category = ModuleCategory.MOVEMENT, cnName = "安全行走")
class SafeWalk : Module() {

    private val airSafeValue = BoolValue("AirSafe", false)

    @EventTarget
    fun onMove(event: MoveEvent) {
        if (airSafeValue.get() || mc.thePlayer.onGround)
            event.isSafeWalk = true
    }
}
