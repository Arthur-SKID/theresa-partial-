
package cn.theresa.features.module.modules.world

import cn.theresa.features.module.manager.Module
import cn.theresa.features.module.manager.ModuleCategory
import cn.theresa.features.module.manager.ModuleInfo

@ModuleInfo(name = "Liquids", description = "Allows you to interact with liquids.", category = ModuleCategory.WORLD, cnName = "液体相互" )
class Liquids : Module()