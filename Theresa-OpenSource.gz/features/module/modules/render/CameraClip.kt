
package cn.theresa.features.module.modules.render

import cn.theresa.features.module.manager.Module
import cn.theresa.features.module.manager.ModuleCategory
import cn.theresa.features.module.manager.ModuleInfo

@ModuleInfo(name = "CameraClip", spacedName = "Camera Clip", description = "Allows you to see through walls in third person view.", category = ModuleCategory.RENDER, cnName = "电影视角")
class CameraClip : Module()