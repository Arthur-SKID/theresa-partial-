
package cn.theresa.features.module.modules.misc

import cn.theresa.features.module.manager.Module
import cn.theresa.features.module.manager.ModuleCategory
import cn.theresa.features.module.manager.ModuleInfo

@ModuleInfo(name = "AntiDesync", spacedName = "Anti Desync", description = "Fix Minecraft's bug with active movement.", category = ModuleCategory.MISC, cnName = "修复移动漏洞")
class AntiDesync : Module()