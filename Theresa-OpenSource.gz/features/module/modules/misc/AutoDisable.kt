
package cn.theresa.features.module.modules.misc

import cn.theresa.ClientMain
import cn.theresa.ui.client.hud.element.elements.Notification
import cn.theresa.event.EventTarget
import cn.theresa.event.WorldEvent
import cn.theresa.event.PacketEvent
import cn.theresa.features.module.manager.Module
import cn.theresa.features.module.manager.ModuleCategory
import cn.theresa.features.module.manager.ModuleInfo
import net.minecraft.network.play.server.S08PacketPlayerPosLook

@ModuleInfo(name = "AutoDisable", spacedName = "Auto Disable", description = "Automatically disable modules for you on flag or world respawn.", category = ModuleCategory.MISC, array = false, cnName = "回弹关闭")
class AutoDisable : Module() {
    @EventTarget
    fun onPacket(event: PacketEvent) {
        if (event.packet is S08PacketPlayerPosLook) disableModules(DisableEvent.FLAG)
    }

    @EventTarget
    fun onWorld(event: WorldEvent) {
        disableModules(DisableEvent.WORLD_CHANGE)
    }

    fun disableModules(enumDisable: DisableEvent) {
        var moduleNames: Int = 0
        ClientMain.moduleManager.modules.filter { it.autoDisables.contains(enumDisable) && it.state }.forEach { it.toggle(); moduleNames++ }

        if (moduleNames <= 0) return
        ClientMain.hud.addNotification(Notification("Disabled $moduleNames ${if (moduleNames > 1) "modules" else "module"} due to ${ when (enumDisable) {
                DisableEvent.FLAG -> "unexpected teleport"
                DisableEvent.WORLD_CHANGE -> "world change"
                else -> "game ended"}}.", Notification.Type.INFO, 1000L))
    }

    companion object {
        fun handleGameEnd() {
            val autoDisableModule = ClientMain.moduleManager[AutoDisable::class.java]!! as AutoDisable
            autoDisableModule.disableModules(DisableEvent.GAME_END)
        }
    }

    enum class DisableEvent {
        FLAG,
        WORLD_CHANGE,
        GAME_END
    }
}