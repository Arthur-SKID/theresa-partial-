
package cn.theresa.features.module.modules.misc

import cn.theresa.event.EventTarget
import cn.theresa.event.PacketEvent
import cn.theresa.features.module.manager.Module
import cn.theresa.features.module.manager.ModuleCategory
import cn.theresa.features.module.manager.ModuleInfo
import net.minecraft.network.play.server.S2EPacketCloseWindow
import net.minecraft.client.gui.inventory.GuiInventory

@ModuleInfo(name = "NoInvClose", spacedName = "No Inv Close", description = "Stops server from closing your Inventory.", category = ModuleCategory.MISC, cnName = "反服务器关闭")
class NoInvClose : Module() {
    @EventTarget
    fun onPacket(event: PacketEvent){
        if (mc.theWorld == null || mc.thePlayer == null) return
        
        if (event.packet is S2EPacketCloseWindow && mc.currentScreen is GuiInventory)
            event.cancelEvent()
    }
}