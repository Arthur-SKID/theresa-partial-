/*
 * Theresa Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge(OLD).
 * https://github.com/WYSI-Foundation/LiquidBouncePlus/
 * LZTN
 * This code belongs to WYSI-Foundation. Please give credits when using this in your repository.
 */
package cn.theresa.features.module.modules.player;

import cn.theresa.ClientMain;
import cn.theresa.event.EventTarget;
import cn.theresa.event.PacketEvent;
import cn.theresa.features.module.manager.Module;
import cn.theresa.features.module.manager.ModuleCategory;
import cn.theresa.features.module.manager.ModuleInfo;
import cn.theresa.utils.MovementUtils;
import cn.theresa.utils.PacketUtils;
import cn.theresa.utils.timer.TimeHelper;
import cn.theresa.utils.timer.Timer;
import cn.theresa.value.FloatValue;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.server.S08PacketPlayerPosLook;

import java.util.ArrayList;

@ModuleInfo(name = "AntiVoid", spacedName = "Anti Void", description = "Prevents you from falling into the void.", category = ModuleCategory.PLAYER,cnName = "虚空不掉落")
public class AntiVoid extends Module {
    public double[] lastGroundPos = new double[3];
    public static FloatValue pullbackTime = new FloatValue("Pullback Time", 800f, 500f, 1500f);
    private final Timer pullTimer = new Timer();
    public static TimeHelper timer = new TimeHelper();
    public static ArrayList<C03PacketPlayer> packets = new ArrayList<>();

    public static boolean isInVoid() {
        for (int i = 0; i <= 128; i++) {
            if (MovementUtils.isOnGround(i)) {
                return false;
            }
        }
        return true;
    }

    @EventTarget
    public void onPacket(PacketEvent event) {
        if (!packets.isEmpty() && mc.thePlayer.ticksExisted < 100)
            packets.clear();
        if (event.getPacket() instanceof C03PacketPlayer) {
            C03PacketPlayer packet = ((C03PacketPlayer) event.getPacket());
            if (isInVoid()) {
                event.cancelEvent();
                packets.add(packet);

                if (timer.isDelayComplete(pullbackTime.get())) {
                    //ChatUtils.debug("Send Packets");
                    PacketUtils.sendPacketNoEvent(new C03PacketPlayer.C04PacketPlayerPosition(lastGroundPos[0], lastGroundPos[1] - 1, lastGroundPos[2], true));
                }
            } else {
                lastGroundPos[0] = mc.thePlayer.posX;
                lastGroundPos[1] = mc.thePlayer.posY;
                lastGroundPos[2] = mc.thePlayer.posZ;
                if (!packets.isEmpty()) {
                    //ChatUtils.debug("Release Packets - " + packets.size());
                    for (Packet p : packets)
                        PacketUtils.sendPacketNoEvent(p);
                    packets.clear();
                }
                timer.reset();
            }
        }
    }

    @EventTarget
    public void onRevPacket(PacketEvent e) {
        if (e.getPacket() instanceof S08PacketPlayerPosLook && packets.size() > 1) {
            packets.clear();
        }
    }
    static final AntiVoid antifall = (AntiVoid) ClientMain.moduleManager.getModule(AntiVoid.class);
    public static boolean isPullbacking() {
        return antifall.getState() && !packets.isEmpty();
    }
    @Override
    public String getTag() {
        return "Hypixel";
    }
}