
package cn.theresa.features.module.modules.player

import cn.theresa.event.EventTarget
import cn.theresa.event.MotionEvent
import cn.theresa.features.module.manager.Module
import cn.theresa.features.module.manager.ModuleCategory
import cn.theresa.features.module.manager.ModuleInfo

import cn.theresa.utils.InventoryUtils
import cn.theresa.value.ListValue
import cn.theresa.value.FloatValue
import net.minecraft.init.Items
import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement
import net.minecraft.network.play.client.C09PacketHeldItemChange

@ModuleInfo(name = "KeepAlive", spacedName = "Keep Alive", description = "Tries to prevent you from dying.", category = ModuleCategory.PLAYER, cnName = "阻止死亡")
class KeepAlive : Module() {

    val modeValue = ListValue("Mode", arrayOf("/heal", "Soup"), "/heal")
    private val maxHealthValue = FloatValue("MaxHealth", 10F, 1F, 20F)

    @EventTarget
    fun onMotion(event: MotionEvent) {
        if (mc.thePlayer!!.health <= maxHealthValue.get()) {
            when (modeValue.get().toLowerCase()) {
                "/heal" -> mc.thePlayer.sendChatMessage("/heal")
                "soup" -> {
                    val soupInHotbar = InventoryUtils.findItem(36, 45, Items.mushroom_stew)

                    if (soupInHotbar != -1) {
                        mc.netHandler.addToSendQueue(C09PacketHeldItemChange(soupInHotbar - 36))
                        mc.netHandler.addToSendQueue(C08PacketPlayerBlockPlacement(mc.thePlayer.inventoryContainer.getSlot(soupInHotbar).stack))
                        mc.netHandler.addToSendQueue(C09PacketHeldItemChange(mc.thePlayer.inventory.currentItem))
                    }
                }
            }
        }
    }
}