
package cn.theresa.features.module.modules.combat

import cn.theresa.features.module.manager.Module
import cn.theresa.features.module.manager.ModuleCategory
import cn.theresa.features.module.manager.ModuleInfo

@ModuleInfo(name = "NoFriends", spacedName = "No Friends", description = "Allows you to attack friends.", category = ModuleCategory.COMBAT, cnName = "攻击目标")
class NoFriends : Module()