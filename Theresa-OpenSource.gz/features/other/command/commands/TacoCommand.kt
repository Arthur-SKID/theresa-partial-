
package cn.theresa.features.other.command.commands

import cn.theresa.ClientMain
import cn.theresa.event.EventTarget
import cn.theresa.event.Listenable
import cn.theresa.event.Render2DEvent
import cn.theresa.event.UpdateEvent
import cn.theresa.features.other.command.Command
import cn.theresa.utils.ClientUtils
import cn.theresa.utils.render.RenderUtils
import net.minecraft.client.gui.ScaledResolution
import net.minecraft.util.ResourceLocation

class TacoCommand : Command("taco", emptyArray()), Listenable {
    private var toggle = false
    private var image = 0
    private var running = 0f
    private val tacoTextures = arrayOf(
            ResourceLocation("theresa/taco/1.png"),
            ResourceLocation("theresa/taco/2.png"),
            ResourceLocation("theresa/taco/3.png"),
            ResourceLocation("theresa/taco/4.png"),
            ResourceLocation("theresa/taco/5.png"),
            ResourceLocation("theresa/taco/6.png"),
            ResourceLocation("theresa/taco/7.png"),
            ResourceLocation("theresa/taco/8.png"),
            ResourceLocation("theresa/taco/9.png"),
            ResourceLocation("theresa/taco/10.png"),
            ResourceLocation("theresa/taco/11.png"),
            ResourceLocation("theresa/taco/12.png")
    )

    init {
        ClientMain.eventManager.registerListener(this)
    }

    /**
     * Execute commands with provided [args]
     */
    override fun execute(args: Array<String>) {
        toggle = !toggle
        ClientUtils.displayChatMessage(if (toggle) "§aTACO TACO TACO. :)" else "§cYou made the little taco sad! :(")
    }

    @EventTarget
    fun onRender2D(event: Render2DEvent) {
        if (!toggle)
            return

        running += 0.15f * RenderUtils.deltaTime
        val scaledResolution = ScaledResolution(mc)
        RenderUtils.drawImage(tacoTextures[image], running.toInt(), scaledResolution.scaledHeight - 60, 64, 32)
        if (scaledResolution.scaledWidth <= running)
            running = -64f
    }

    @EventTarget
    fun onUpdate(event: UpdateEvent) {
        if (!toggle) {
            image = 0
            return
        }

        image++
        if (image >= tacoTextures.size) image = 0
    }

    override fun handleEvents() = true

    override fun tabComplete(args: Array<String>): List<String> {
        return listOf("TACO")
    }
}