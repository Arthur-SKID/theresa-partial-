
package cn.theresa.features.module.modules.render

import cn.theresa.features.module.manager.Module
import cn.theresa.features.module.manager.ModuleCategory
import cn.theresa.features.module.manager.ModuleInfo
import cn.theresa.value.FloatValue

@ModuleInfo(name = "NoFOV", spacedName = "No FOV", description = "Disables FOV changes caused by speed effect, etc.", category = ModuleCategory.RENDER, cnName = "无疾跑视角")
class NoFOV : Module() {
    val fovValue = FloatValue("FOV", 1f, 0f, 1.5f, "x")
}
