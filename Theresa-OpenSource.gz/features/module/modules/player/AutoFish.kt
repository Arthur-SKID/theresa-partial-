
package cn.theresa.features.module.modules.player

import cn.theresa.event.EventTarget
import cn.theresa.event.UpdateEvent
import cn.theresa.features.module.manager.Module
import cn.theresa.features.module.manager.ModuleCategory
import cn.theresa.features.module.manager.ModuleInfo
import cn.theresa.utils.timer.MSTimer
import net.minecraft.item.ItemFishingRod

@ModuleInfo(name = "AutoFish", spacedName = "Auto Fish", description = "Automatically catches fish when using a rod.", category = ModuleCategory.PLAYER, cnName = "虚空钓鱼")
class AutoFish : Module() {

    private val rodOutTimer = MSTimer()

    @EventTarget
    fun onUpdate(event: UpdateEvent) {
        if (mc.thePlayer.heldItem == null || mc.thePlayer.heldItem.item !is ItemFishingRod)
            return

        if (rodOutTimer.hasTimePassed(500L) && mc.thePlayer.fishEntity == null || (mc.thePlayer.fishEntity != null && mc.thePlayer.fishEntity.motionX == 0.0 && mc.thePlayer.fishEntity.motionZ == 0.0 && mc.thePlayer.fishEntity.motionY != 0.0)) {
            mc.rightClickMouse()
            rodOutTimer.reset()
        }
    }
}
