
package cn.theresa.features.module.modules.render

import cn.theresa.features.module.manager.Module
import cn.theresa.features.module.manager.ModuleCategory
import cn.theresa.features.module.manager.ModuleInfo
import cn.theresa.value.ListValue

import net.minecraft.util.ResourceLocation

@ModuleInfo(name = "Cape", description = "ClientMain capes.", category = ModuleCategory.RENDER,cnName = "披风")
class Cape : Module() {

    val styleValue = ListValue("Style", arrayOf("Dark", "Darker", "Light", "Special1", "Special2"), "Dark")

    private val capeCache = hashMapOf<String, CapeStyle>()

    fun getCapeLocation(value: String): ResourceLocation {
        if (capeCache[value.toUpperCase()] == null) {
            try {
                capeCache[value.toUpperCase()] = CapeStyle.valueOf(value.toUpperCase())
            } catch (e: Exception) {
                capeCache[value.toUpperCase()] = CapeStyle.DARK
            }
        }
        return capeCache[value.toUpperCase()]!!.location
    }

    enum class CapeStyle(val location: ResourceLocation) {
        DARK(ResourceLocation("theresa/cape/dark.png")),
        DARKER(ResourceLocation("theresa/cape/darker.png")),
        LIGHT(ResourceLocation("theresa/cape/light.png")),
        SPECIAL1(ResourceLocation("theresa/cape/special1.png")),
        SPECIAL2(ResourceLocation("theresa/cape/special2.png"))
    }

    override val tag: String
        get() = styleValue.get()

}