
package cn.theresa.features.module.modules.movement

import cn.theresa.features.module.manager.Module
import cn.theresa.features.module.manager.ModuleCategory
import cn.theresa.features.module.manager.ModuleInfo

@ModuleInfo(name = "NoJumpDelay", spacedName = "No Jump Delay", description = "Removes delay between jumps.", category = ModuleCategory.MOVEMENT, cnName = "无跳跃延迟")
class NoJumpDelay : Module()