
package cn.theresa.features.module.modules.combat

import cn.theresa.ClientMain
import cn.theresa.event.*
import cn.theresa.features.module.manager.Module
import cn.theresa.features.module.manager.ModuleCategory
import cn.theresa.features.module.manager.ModuleInfo
import cn.theresa.features.module.modules.movement.Fly
import cn.theresa.features.other.special.CombatListener
import cn.theresa.utils.timer.MSTimer
import cn.theresa.value.FloatValue
import cn.theresa.value.IntegerValue
import cn.theresa.value.ListValue
import cn.theresa.value.BoolValue
import net.minecraft.entity.EntityLivingBase
import net.minecraft.network.play.client.C03PacketPlayer
import net.minecraft.network.play.client.C07PacketPlayerDigging
import net.minecraft.network.play.client.C03PacketPlayer.C04PacketPlayerPosition
import kotlin.random.Random

@ModuleInfo(name = "Criticals", description = "Automatically deals critical hits.", category = ModuleCategory.COMBAT, cnName = "暴击")
class Criticals : Module() {

    val modeValue = ListValue("Mode", arrayOf("BlocksMC","Hypixel", "SimplePacket", "NoGround", "Jump", "Visual", "Edit"), "Packet")
    val delayValue = IntegerValue("Delay", 0, 0, 500, "ms")
    private val jumpHeightValue = FloatValue("JumpHeight", 0.42F, 0.1F, 0.42F) { modeValue.get().equals("jump", true) }
    private val downYValue = FloatValue("DownY", 0f, 0f, 0.1F) { modeValue.get().equals("jump", true) }
    private val hurtTimeValue = IntegerValue("HurtTime", 10, 0, 10)
    private val onlyAuraValue = BoolValue("OnlyAura", false)

    val msTimer = MSTimer()
    private var readyCrits = false
    private var canCrits = true
    private var counter = 0

    override fun onEnable() {
        if (modeValue.get().equals("NoGround", ignoreCase = true))
            mc.thePlayer.jump()
        canCrits = true
        counter = 0;
    }

    @EventTarget
    fun onAttack(event: AttackEvent) {
        if (onlyAuraValue.get() && !ClientMain.moduleManager[KillAura::class.java]!!.state && !ClientMain.moduleManager[TeleportAura::class.java]!!.state) return

        if (event.targetEntity is EntityLivingBase) {
            val entity = event.targetEntity

            if (!mc.thePlayer.onGround || mc.thePlayer.isOnLadder || mc.thePlayer.isInWeb || mc.thePlayer.isInWater ||
                    mc.thePlayer.isInLava || mc.thePlayer.ridingEntity != null || entity.hurtTime > hurtTimeValue.get() ||
                    ClientMain.moduleManager[Fly::class.java]!!.state || !msTimer.hasTimePassed(delayValue.get().toLong()))
                return

            val x = mc.thePlayer.posX
            val y = mc.thePlayer.posY
            val z = mc.thePlayer.posZ

            when (modeValue.get().toLowerCase()) {
                "hypixel" ->{
                    mc.netHandler.addToSendQueue(C04PacketPlayerPosition(x, y + CombatListener.getRandomFloatNum(0,14), z, true))
                    mc.netHandler.addToSendQueue(C04PacketPlayerPosition(x, y + CombatListener.getRandomFloatNum(0,14), z, false))
                    mc.netHandler.addToSendQueue(C04PacketPlayerPosition(x, y + CombatListener.getRandomFloatNum(0,14), z, false))
                    mc.netHandler.addToSendQueue(C04PacketPlayerPosition(x, y + CombatListener.getRandomFloatNum(0,14), z, false))
                    mc.thePlayer.onCriticalHit(entity)
                }
                "blocksmc" -> {
                    mc.netHandler.addToSendQueue(C04PacketPlayerPosition(x, y + 0.05250000001304, z, true))
                    mc.netHandler.addToSendQueue(C04PacketPlayerPosition(x, y + 0.00150000001304, z, false))
                    mc.netHandler.addToSendQueue(C04PacketPlayerPosition(x, y + 0.01400000001304, z, false))
                    mc.netHandler.addToSendQueue(C04PacketPlayerPosition(x, y + 0.00150000001304, z, false))
                    mc.thePlayer.onCriticalHit(entity)
                }

                "simplepacket" -> {
                    mc.netHandler.addToSendQueue(C04PacketPlayerPosition(mc.thePlayer.posX, mc.thePlayer.posY + 0.0625, mc.thePlayer.posZ, false))
		            mc.netHandler.addToSendQueue(C04PacketPlayerPosition(mc.thePlayer.posX, mc.thePlayer.posY + 0.09858, mc.thePlayer.posZ, false))
		            mc.netHandler.addToSendQueue(C04PacketPlayerPosition(mc.thePlayer.posX, mc.thePlayer.posY + 0.04114514, mc.thePlayer.posZ, false))
		            mc.netHandler.addToSendQueue(C04PacketPlayerPosition(mc.thePlayer.posX, mc.thePlayer.posY + 0.025, mc.thePlayer.posZ, false))
                }

                "jump" -> {
                    if (mc.thePlayer.onGround) {
                        mc.thePlayer.motionY = jumpHeightValue.get().toDouble()
                    } else {
                        mc.thePlayer.motionY -= downYValue.get()
                    }
                }

                "visual" -> mc.thePlayer.onCriticalHit(entity)
            }

            readyCrits = true
            msTimer.reset()
        }
    }

    @EventTarget
    fun onPacket(event: PacketEvent) {
        if (onlyAuraValue.get() && !ClientMain.moduleManager[KillAura::class.java]!!.state) return
        
        val packet = event.packet

        when (modeValue.get().toLowerCase()) {

            "noground" -> {
                if (packet is C03PacketPlayer) {
                    packet.onGround = false
                }
            }

            "edit" -> {
                if (readyCrits) {
                    if (packet is C03PacketPlayer) {
                        packet.onGround = false
                    }
                    readyCrits = false
                }
            }
        }

    }

    override val tag: String
        get() = modeValue.get()
}


