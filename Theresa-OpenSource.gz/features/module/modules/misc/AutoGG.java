package cn.theresa.features.module.modules.misc;

import cn.theresa.features.module.modules.movement.Speed;
import cn.theresa.features.module.modules.player.InvManager;
import cn.theresa.features.module.modules.world.Scaffold;
import cn.theresa.ClientMain;
import cn.theresa.event.EventTarget;
import cn.theresa.event.PacketEvent;
import cn.theresa.features.module.manager.Module;
import cn.theresa.features.module.manager.ModuleCategory;
import cn.theresa.features.module.manager.ModuleInfo;
import cn.theresa.features.module.modules.combat.KillAura;
import cn.theresa.features.module.modules.world.ChestStealer;
import cn.theresa.ui.client.hud.element.elements.Notification;
import cn.theresa.value.BoolValue;
import cn.theresa.value.IntegerValue;
import cn.theresa.value.ListValue;
import cn.theresa.value.TextValue;
import net.minecraft.network.Packet;
import net.minecraft.network.play.server.S02PacketChat;

import java.util.Objects;
import java.util.Timer;
import java.util.TimerTask;


@ModuleInfo(name = "AutoGG", description = "End a game send GG", category = ModuleCategory.MISC,cnName = "自动嘲讽")
public class AutoGG extends Module {
    private final TextValue ggMessage = new TextValue("GGMessage", "[Theresa] GG");
    private final TextValue winMessage = new TextValue("WinMessage", "[Theresa] L 你的参数真拉");
    private final BoolValue play = new BoolValue("AutoPlay",true);
    private final BoolValue disable = new BoolValue("AutoDisable",true);
    private final ListValue mode = new ListValue("Mode", new String[] {"BedWars_1v1", "BedWars_2v2", "BedWars_3v3","BedWars_4v4", "SkyWars_Solo", "SkyWars_Solo_Insane","SkyWars_Solo_LuckyBlock","SkyWars_Team","SkyWars_Team_Insane","SkyWars_Team_LuckyBlock","SurivialGames_Solo","SurivialGames_Team","MiniWalls"}, "SkyWars_Solo");
    private final IntegerValue delay = new IntegerValue("Delay", 3, 0, 5);
    public static boolean winning = false;
    private final Timer timer1 = new Timer();

    public int win = 0;
    int a;

    @Override
    public String getTag() {
        return mode.get();
    }

    @EventTarget
    public void onPacket(PacketEvent packetEvent) {
        Packet<?> packet = packetEvent.getPacket();
        if(packet instanceof S02PacketChat) {
            if(((S02PacketChat) packet).getChatComponent().getUnformattedText().contains(winMessage.get())) {
                mc.thePlayer.sendChatMessage(ggMessage.get());
                winning = true;
                int delay1 = delay.get();
                if(disable.get()) {
                    Objects.requireNonNull(ClientMain.moduleManager.getModule(KillAura.class)).setState(false);
                    Objects.requireNonNull(ClientMain.moduleManager.getModule(ChestStealer.class)).setState(false);
                    Objects.requireNonNull(ClientMain.moduleManager.getModule(InvManager.class)).setState(false);
                    Objects.requireNonNull(ClientMain.moduleManager.getModule(Speed.class)).setState(false);
                    Objects.requireNonNull(ClientMain.moduleManager.getModule(Scaffold.class)).setState(false);
                    win += 1;
                    ClientMain.hud.addNotification(new Notification("Will Send You to Next Game", Notification.Type.INFO, 3000L));
                }
                if(play.get()) {
                    this.timer1.schedule(new TimerTask() {
                        public void run() {
                            switch (mode.get()) {
                                case "BedWars_1v1":
                                    mc.thePlayer.sendChatMessage("/play bedwars_eight_one");
                                    break;
                                case "BedWars_2v2":
                                    mc.thePlayer.sendChatMessage("/play bedwars_eight_two");
                                    break;
                                case "BedWars_3v3":
                                    mc.thePlayer.sendChatMessage("/play bedwars_four_three");
                                    break;
                                case "BedWars_4v4":
                                    mc.thePlayer.sendChatMessage("/play bedwars_four_four");
                                    break;
                                case "SkyWars_Solo":
                                    mc.thePlayer.sendChatMessage("/play solo_normal");
                                    break;
                                case "SkyWars_Solo_Insane":
                                    mc.thePlayer.sendChatMessage("/play solo_insane");
                                    break;
                                case "SkyWars_Solo_LuckyBlock":
                                    mc.thePlayer.sendChatMessage("/play solo_insane_lucky");
                                    break;
                                case "SkyWars_Team":
                                    mc.thePlayer.sendChatMessage("/play teams_normal");
                                    break;
                                case "SkyWars_Team_Insane":
                                    mc.thePlayer.sendChatMessage("/play teams_insane");
                                    break;
                                case "SkyWars_Team_LuckyBlock":
                                    mc.thePlayer.sendChatMessage("/play teams_insane_lucky");
                                    break;
                                case "SurivialGames_Solo":
                                    mc.thePlayer.sendChatMessage("/play blitz_solo_normal");
                                    break;
                                case "SurivialGames_Team":
                                    mc.thePlayer.sendChatMessage("/play blitz_teams_normal");
                                    break;
                                case "MiniWalls":
                                    mc.thePlayer.sendChatMessage("/play arcade_mini_walls");
                                    break;
                            }
                            winning = false;
                        }
                    }, (delay.get().longValue() * 10) * 100);
                }
            }
        }
    }

    @Override
    public void onDisable() {
        a = -40;
        winning = false;
    }

    public int getWin(){
        return win;
    }

}