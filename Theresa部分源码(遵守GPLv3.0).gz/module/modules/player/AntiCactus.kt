
package cn.theresa.features.module.modules.player

import cn.theresa.event.BlockBBEvent
import cn.theresa.event.EventTarget
import cn.theresa.features.module.manager.Module
import cn.theresa.features.module.manager.ModuleCategory
import cn.theresa.features.module.manager.ModuleInfo
import net.minecraft.block.BlockCactus
import net.minecraft.util.AxisAlignedBB

@ModuleInfo(name = "AntiCactus", spacedName = "Anti Cactus", description = "Prevents cactuses from damaging you.", category = ModuleCategory.PLAYER, cnName = "防止仙人掌")
class AntiCactus : Module() {

    @EventTarget
    fun onBlockBB(event: BlockBBEvent) {
        if (event.block is BlockCactus)
            event.boundingBox = AxisAlignedBB(event.x.toDouble(), event.y.toDouble(), event.z.toDouble(),
                    event.x + 1.0, event.y + 1.0, event.z + 1.0)
    }
}
