
package cn.theresa.features.module.modules.render

import cn.theresa.ClientMain
import cn.theresa.event.*
import cn.theresa.features.module.manager.Module
import cn.theresa.features.module.manager.ModuleCategory
import cn.theresa.features.module.manager.ModuleInfo
import cn.theresa.features.module.modules.combat.BowAimbot
import cn.theresa.features.module.modules.combat.KillAura
import cn.theresa.features.module.modules.exploit.Disabler
import cn.theresa.features.module.modules.movement.Fly
import cn.theresa.features.module.modules.movement.Sprint
import cn.theresa.features.module.modules.world.*
import cn.theresa.utils.RotationUtils
import cn.theresa.value.ListValue
import net.minecraft.network.play.client.C03PacketPlayer

@ModuleInfo(name = "Rotations", description = "Allows you to see server-sided head and body rotations.", category = ModuleCategory.RENDER, cnName = "转头")
class Rotations : Module() {

    val modeValue = ListValue("Mode", arrayOf("Head", "Body"), "Body")

    private var playerYaw: Float? = null

    @EventTarget
    fun onRender3D(event: Render3DEvent) {
        if (modeValue.get().equals("head", true) && RotationUtils.serverRotation != null)
            mc.thePlayer.rotationYawHead = RotationUtils.serverRotation.yaw
    }
    @EventTarget
    fun onPacket(event: PacketEvent) {
        if (modeValue.get().equals("head", true) || !shouldRotate() || mc.thePlayer == null) {
            playerYaw = null
            return
        }

        val packet = event.packet
        if (packet is C03PacketPlayer && packet.rotating) {
            playerYaw = packet.yaw
            mc.thePlayer.renderYawOffset = packet.getYaw()
            mc.thePlayer.rotationYawHead = packet.getYaw()
        } else {
            if (playerYaw != null)
                mc.thePlayer.renderYawOffset = this.playerYaw!!
            mc.thePlayer.rotationYawHead = mc.thePlayer.renderYawOffset
        }
    }

    private fun getState(module: Class<out Module>) = ClientMain.moduleManager[module]!!.state

    fun shouldRotate(): Boolean {
        val killAura = ClientMain.moduleManager.getModule(KillAura::class.java) as KillAura
        val disabler = ClientMain.moduleManager.getModule(Disabler::class.java) as Disabler
        val sprint = ClientMain.moduleManager.getModule(Sprint::class.java) as Sprint
        return getState(Scaffold::class.java) || 
                (getState(Sprint::class.java) && sprint.allDirectionsValue.get() && sprint.moveDirPatchValue.get()) ||
                (getState(KillAura::class.java) && killAura.target != null) ||
                (getState(Disabler::class.java) && disabler.canRenderInto3D) ||
                getState(BowAimbot::class.java) || getState(Fucker::class.java) ||
                getState(ChestAura::class.java) || getState(Fly::class.java)
    }
}
