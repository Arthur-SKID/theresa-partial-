
package cn.theresa.features.module.modules.movement;

import cn.theresa.event.EventTarget;
import cn.theresa.event.UpdateEvent;
import cn.theresa.features.module.manager.Module;
import cn.theresa.features.module.manager.ModuleCategory;
import cn.theresa.features.module.manager.ModuleInfo;

@ModuleInfo(name = "LadderJump", spacedName = "Ladder Jump", description = "Boosts you up when touching a ladder.", category = ModuleCategory.MOVEMENT,cnName = "梯子跳跃")
public class LadderJump extends Module {

    static boolean jumped;

    @EventTarget
    public void onUpdate(UpdateEvent event) {
        if(mc.thePlayer.onGround) {
            if(mc.thePlayer.isOnLadder()) {
                mc.thePlayer.motionY = 1.5D;
                jumped = true;
            }else
                jumped = false;
        }else if(!mc.thePlayer.isOnLadder() && jumped)
            mc.thePlayer.motionY += 0.059D;
    }
}
